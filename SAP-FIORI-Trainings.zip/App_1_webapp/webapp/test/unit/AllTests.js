sap.ui.define([
	"int_test/int_test/test/unit/controller/View1.controller"
], function () {
	"use strict";
});