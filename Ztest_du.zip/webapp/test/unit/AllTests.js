sap.ui.define([
	"com/ra1vi2/ducattest/Ztest_ducat/test/unit/controller/View1.controller"
], function () {
	"use strict";
});