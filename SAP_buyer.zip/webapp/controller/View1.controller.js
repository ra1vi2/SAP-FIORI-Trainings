sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/json/JSONModel",
  "sap/m/ColumnListItem",
  "sap/m/Label",
  "sap/m/Token",
  "sap/m/MessageToast",
  "sap/ui/model/odata/ODataModel",
  "sap/m/Dialog",
  "sap/m/List",
  "sap/m/StandardListItem",
  "sap/m/Button",
  "sap/m/ButtonType"
], function (Controller, JSONModel, ColumnListItem, Label, Token, MessageToast,
  Odatareq, Dialog, List, StandardListItem, Button, ButtonType) {
  "use strict";
  return Controller.extend("com.zbuyer.ZBUYER_PULL.controller.View1", {
    onInit: function () {


      var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BUYER_PULL_LIST_ODATA_SRV/", false);
      var oView = this.getView();
      oView.setModel(oModel);
      this._oInput = this.getView()
        .byId("filter_werks");
      this._oInput_mat = this.getView()
        .byId("filter_matnr");
      this._oInput_ekg = this.getView()
        .byId("filter_ekgrp");
      this._oInput_sitegroup = this.getView()
        .byId("filter_sitegroup");
      this._oInput_lgort = this.getView()
        .byId("filter_lgort");
      this._oInput_dept = this.getView()
        .byId("filter_dept");
      this._oInput_vendor = this.getView()
        .byId("filter_vendor");

      var selectModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BP_SEARCH_HELP_ODATA_SRV/", false);
      var selectId = this.getView().byId("idCode1");
      selectId.setModel(selectModel);
      //this.getView().byId("idCode1").setModel(this.getOwnerComponent().getModel("deposition_code"));
      // var dataModel = this.getOwnerComponent()
      //   .getModel("deposition_code");
      // this.getView()
      //  .setModel(dataModel, "DataModel");
    },
    beforeRebindTable: function (oEvent) {

      var oBindingParams = oEvent.getParameter("bindingParams");
      var aFilters = oBindingParams.filters;
      // Create the table object
      var oSmartTable = oEvent.getSource();
      // Get the SmartFilterBarID
      var oSmartFilterBar = this.byId(oSmartTable.getSmartFilterId());
      if (oSmartFilterBar instanceof sap.ui.comp.smartfilterbar.SmartFilterBar) {

        var f_matnr = oSmartFilterBar.getControlByKey("Matnr");
        f_matnr.setValueState(sap.ui.core.ValueState.None);
        var fv_matnr = f_matnr.getValue();

        var mat_toke = f_matnr.getTokens();
        var mat_sdta = mat_toke.map(function (token) {
          return token.getKey();
        }).join(",");
        var mat_val;
        mat_val = mat_sdta.split(",");

        var f_vendor = oSmartFilterBar.getControlByKey("Lifnr");
        f_vendor.setValueState(sap.ui.core.ValueState.None);
         var fv_vendor =   f_vendor.getValue();

        var vend_toke = f_vendor.getTokens();
        var vend_sdta = vend_toke.map(function (token) {
          return token.getKey();
        }).join(",");
        var vend_val = vend_sdta.split(",");

        var f_werks = oSmartFilterBar.getControlByKey("Werks");
        f_werks.setValueState(sap.ui.core.ValueState.None);
        var fv_werks = f_werks.getValue();

        var f_ekgrp = oSmartFilterBar.getControlByKey("Ekgrp");
        var fv_ekgrp = f_ekgrp.getValue();

        var f_sitegroup = oSmartFilterBar.getControlByKey("LocGroup");
        f_sitegroup.setValueState(sap.ui.core.ValueState.None);
        var fv_sitegroup = f_sitegroup.getValue();

        var f_lgort = oSmartFilterBar.getControlByKey("Lgort");
        var fv_lgort = f_lgort.getValue();

        var f_dept = oSmartFilterBar.getControlByKey("ZzAltDept");
        var fv_dept = f_dept.getValue();

        /*
        if (fv_vendor == "" && fv_matnr == "")
        {
          MessageToast.show("Please enter Vendor or Article");
          //f_vendor.setValueState(sap.ui.core.ValueState.Error);
          //f_matnr.setValueState(sap.ui.core.ValueState.Error);
        } */
        if (fv_werks == "" && fv_sitegroup == "") {
          MessageToast.show("Please enter Plant or SiteGroup");
          //f_werks.setValueState(sap.ui.core.ValueState.Error);
          //  f_sitegroup.setValueState(sap.ui.core.ValueState.Error);

        } else {
          if (mat_val.length > 0 && mat_val[0] !== "") {
            //oBindingParams.filters.push(new sap.ui.model.Filter("Matnr", "EQ", fv_matnr));
            var j;
            for (j = 0; j < mat_val.length; j++) {
              oBindingParams.filters.push(new sap.ui.model.Filter("Matnr", "EQ", mat_val[j]));
            }


          }else if(fv_matnr != "")
            {
            oBindingParams.filters.push(new sap.ui.model.Filter("Matnr", "EQ", fv_matnr));
            }
          if (fv_werks != "") {
            oBindingParams.filters.push(new sap.ui.model.Filter("Werks", "EQ", fv_werks));
          }
          if (fv_ekgrp != "") {
            oBindingParams.filters.push(new sap.ui.model.Filter("Ekgrp", "EQ", fv_ekgrp));
          }


          if (fv_sitegroup != "") {
            oBindingParams.filters.push(new sap.ui.model.Filter("LocGroup", "EQ", fv_sitegroup));
          }

          if (fv_lgort != "") {
            oBindingParams.filters.push(new sap.ui.model.Filter("Lgort", "EQ", fv_lgort));
          }

          if (fv_dept != "") {
            oBindingParams.filters.push(new sap.ui.model.Filter("ZzAltDept", "EQ", fv_dept));
          }

          if (vend_val.length > 0 && vend_val[0] !== "") {
            var i;
            for (i = 0; i < vend_val.length; i++) {
              oBindingParams.filters.push(new sap.ui.model.Filter("Lifnr", "EQ", vend_val[i]));
            }


          }
          else if(fv_vendor != "")
            {
            oBindingParams.filters.push(new sap.ui.model.Filter("Lifnr", "EQ", fv_vendor));
            }
        }
      }

    },
    onPress: function (oEvent) {
    if((this.getView().byId("vend_auth").getValue() == "") &&
    this.getView().byId("vend_auth").getEnabled()){
    this.getView().byId("vend_auth").setValueState(sap.ui.core.ValueState.Error);
    }
    else{
      if (!this.pressDialog) {
        this.pressDialog = new Dialog({
          title: 'Enter Comments',
          content: new sap.m.Input({
            id: "reasonCode"

          }),
          beginButton: new Button({
            type: ButtonType.Emphasized,
            text: 'OK',
            press: function () {
              var reasoncode = sap.ui.getCore().byId("reasonCode").getValue();
              if (!reasoncode == '') {
                this.onExecute(reasoncode);
                 var oTable_ = this.getView()
        .byId("smartTable_ResponsiveTable")
        .getTable();
        oTable_.getBinding("rows").refresh();
                this.pressDialog.close();
              } else {
                sap.ui.getCore().byId("reasonCode").setValueState(sap.ui.core.ValueState.Error);
              }
            }.bind(this)
          }),
          endButton: new Button({
            text: 'Close',
            press: function () {

              this.pressDialog.close();
            }.bind(this)
          })
        });

        //to get access to the global model
        this.getView().addDependent(this.pressDialog);
      }

      this.pressDialog.open();
      }
    },

    onChangedrop: function (Oevent) {
      var drop_key = this.getView().byId("idCode1").getSelectedItem().getProperty("key");
      if ((drop_key == "R") || (drop_key == "X")) {
        this.getView().byId("vend_auth").setEnabled(true);
      } else {
        this.getView().byId("vend_auth").setEnabled(false);
        this.getView().byId("vend_auth").setValue("");
      }

    },
    onExecute: function (reasoncode) {
      //get Value from drop down
      var drop_text = this.getView().byId("idCode1").getSelectedItem().getProperty("text");
      var drop_key = this.getView().byId("idCode1").getSelectedItem().getProperty("key");
      var vend_auth = this.getView().byId("vend_auth").getValue();
      //get selected rows from table
      var selectedRow = [];
       var oTable = this.getView()
        .byId("smartTable_ResponsiveTable")
        .getTable();

      var j;
      var oItems = oTable.getSelectedIndices();
      for (var i = 0; i < oItems.length; i++) {
        j = oItems[i];
        var l_ekgrp = oTable.getContextByIndex(j)
          .getProperty("Ekgrp");
        var l_Matnr = oTable.getContextByIndex(j)
          .getProperty("Matnr");
        var l_Werks = oTable.getContextByIndex(j)
          .getProperty("Werks");
        var l_Lgort = oTable.getContextByIndex(j)
          .getProperty("Lgort");
        var l_Mtart = oTable.getContextByIndex(j)
          .getProperty("Mtart");
        var l_Matkl = oTable.getContextByIndex(j)
          .getProperty("Matkl");
        var l_Maktx = oTable.getContextByIndex(j)
          .getProperty("Maktx");
        var l_Meins = oTable.getContextByIndex(j)
          .getProperty("Meins");

        var l_qty = oTable.getContextByIndex(j)
          .getProperty("Qty");
        if (typeof l_qty === "undefined") {
          l_qty = "0.0";

        }

        if (typeof vend_auth === "undefined") {
          vend_auth = "";

        }

        var ZzAltDept = oTable.getContextByIndex(j)
          .getProperty("ZzAltDept");

        var l_lifnr = oTable.getContextByIndex(j)
          .getProperty("Lifnr");

        selectedRow.push({
          Matnr: l_Matnr,
          Werks: l_Werks,
          Lgort: l_Lgort,
          ZzAltDept: ZzAltDept,
          Ekgrp: l_ekgrp,
          Lifnr: l_lifnr,
          Reswk: '',
          VendorAuth: vend_auth,
          Meins: l_Meins,
          Qty: l_qty,
          Maktx: l_Maktx,
          BuyerDp: drop_key,
          BuyerDpDesc: drop_text,
          Batch: '',
          Comments: reasoncode

        });
      } //for loop ends here
      // now adding header information
      var oEntry1 = {};
      oEntry1.Buyer = l_ekgrp;
      oEntry1.HeaderItemSet = selectedRow;

      //Create and set the Model
      var oUpModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BUYER_PULL_LIST_ODATA_SRV/");
      oUpModel.create("/HeaderSet", oEntry1, {
        success: function (oResponse) {
          MessageToast.show("Records submitted successfully");


        },
        error: function (oError) {
          MessageToast.show("Could not Update");
        }
      });

   
    },

    //////search hekp matnr starts&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    onValueHelpRequested_matnr: function () {
      var oColModel = this.getOwnerComponent()
        .getModel("matnr_col");
      this.oProductsModel_mat = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BP_SEARCH_HELP_ODATA_SRV/", false);
      this.getView().byId("filter_matnr")
        .setModel(this.oProductsModel_mat);
      var aCols = oColModel.getData()
        .cols;
      this._oValueHelpDialog_mat = sap.ui.xmlfragment("com.zbuyer.ZBUYER_PULL.view.valuehelp_matnr", this);
      this.getView()
        .addDependent(this._oValueHelpDialog_mat);
        var mat_help_tab = this._oValueHelpDialog_mat.getTable();
    //  this._oValueHelpDialog_mat.getTableAsync()
       // .then(function (oTable) {
          mat_help_tab.setModel(this.oProductsModel_mat);
          mat_help_tab.setModel(oColModel, "columns");
          if (mat_help_tab.bindRows) {
            mat_help_tab.bindAggregation("rows", "/CbglwiMatnrESet");
          }
          if (mat_help_tab.bindItems) {
            mat_help_tab.bindAggregation("items", "/CbglwiMatnrESet", function () {
              return new ColumnListItem({
                cells: aCols.map(function (column) {
                  return new Label({
                    text: "{" + column.template + "}"
                  });
                })
              });
            });
          }
          this._oValueHelpDialog_mat.update();
       // }.bind(this));
      
      /*  this._oValueHelpDialog_mat.setTokens([
          new Token({
            key: this._oInput_mat.getSelectedKey(),
            text: this._oInput_mat.getValue()
          })
        ]);
        */
      this._oValueHelpDialog_mat.setTokens(this._oInput_mat.getTokens());
      this._oValueHelpDialog_mat.open();
    },
    onValueHelpOkPress_mat: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput_mat.setTokens(aTokens);
    //  this._oInput_mat.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog_mat.close();
    },
    selectionchange_mat: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput_mat.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog_mat.close();
    },
    onValueHelpCancelPress_mat: function () {
      this._oValueHelpDialog_mat.close();
    },
    onValueHelpAfterClose_mat: function () {
      this._oValueHelpDialog_mat.destroy();
    },
    ////value help request matnr ends///////

    ///////////////////////plue help request werks start////
    onValueHelpRequested_werks: function () {
      var oColModel = this.getOwnerComponent()
        .getModel("werks_col");
      this.oProductsModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BP_SEARCH_HELP_ODATA_SRV/", false);
      this.getView().byId("filter_werks")
        .setModel(this.oProductsModel);
      var aCols = oColModel.getData()
        .cols;
      this._oValueHelpDialog = sap.ui.xmlfragment("com.zbuyer.ZBUYER_PULL.view.valuehelp_werks", this);
      this.getView()
        .addDependent(this._oValueHelpDialog);
     // this._oValueHelpDialog.getTableAsync()
       // .then(function (oTable) {
       var val_help_werks = this._oValueHelpDialog.getTable();
          val_help_werks.setModel(this.oProductsModel);
          val_help_werks.setModel(oColModel, "columns");
          if (val_help_werks.bindRows) {
            val_help_werks.bindAggregation("rows", "/MdgBsMatWerksElemSet");
          }
          if (val_help_werks.bindItems) {
            val_help_werks.bindAggregation("items", "/MdgBsMatWerksElemSet", function () {
              return new ColumnListItem({
                cells: aCols.map(function (column) {
                  return new Label({
                    text: "{" + column.template + "}"
                  });
                })
              });
            });
          }
          this._oValueHelpDialog.update();
      //  }.bind(this));
      this._oValueHelpDialog.setTokens([
        new Token({
          key: this._oInput.getSelectedKey(),
          text: this._oInput.getValue()
        })
      ]);
      this._oValueHelpDialog.open();
    },
    onValueHelpOkPress: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog.close();
    },
    selectionchange: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog.close();
    },
    onValueHelpCancelPress: function () {
      this._oValueHelpDialog.close();
    },
    onValueHelpAfterClose: function () {
      this._oValueHelpDialog.destroy();
    },

    ////value help request werks ends///////

    ////value help request ekgrp start //////
    onValueHelpRequested_ekgrp: function () {
      var oColModel = this.getOwnerComponent()
        .getModel("ekgrp_col");
      this.oProductsModel_ekg = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BP_SEARCH_HELP_ODATA_SRV/", false);
      this.getView().byId("filter_ekgrp")
        .setModel(this.oProductsModel_ekg);
      var aCols = oColModel.getData()
        .cols;
      this._oValueHelpDialog_ekg = sap.ui.xmlfragment("com.zbuyer.ZBUYER_PULL.view.valuehelp_ekgrp", this);
      this.getView()
        .addDependent(this._oValueHelpDialog_ekg);
      //this._oValueHelpDialog_ekg.getTableAsync()
        //.then(function (oTable) {
         var val_ekgrp =  this._oValueHelpDialog_ekg.getTable();
          val_ekgrp.setModel(this.oProductsModel_ekg);
          val_ekgrp.setModel(oColModel, "columns");
          if (val_ekgrp.bindRows) {
            val_ekgrp.bindAggregation("rows", "/HT024Set");
          }
          if (val_ekgrp.bindItems) {
            val_ekgrp.bindAggregation("items", "/HT024Set", function () {
              return new ColumnListItem({
                cells: aCols.map(function (column) {
                  return new Label({
                    text: "{" + column.template + "}"
                  });
                })
              });
            });
          }
          this._oValueHelpDialog_ekg.update();
       // }.bind(this));
      this._oValueHelpDialog_ekg.setTokens([
        new Token({
          key: this._oInput_ekg.getSelectedKey(),
          text: this._oInput_ekg.getValue()
        })
      ]);
      this._oValueHelpDialog_ekg.open();
    },
    onValueHelpOkPress_ekg: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput_ekg.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog_ekg.close();
    },
    selectionchange_ekg: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput_ekg.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog_ekg.close();
    },
    onValueHelpCancelPress_ekg: function () {
      this._oValueHelpDialog_ekg.close();
    },
    onValueHelpAfterClose_ekg: function () {
      this._oValueHelpDialog_ekg.destroy();
    },
    ////value help for ekgrp ends&nb
    /////department search help
    onValueHelpRequested_dept: function () {
      var oColModel = this.getOwnerComponent()
        .getModel("dept_col");
      this.oProductsModel_dept = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BP_SEARCH_HELP_ODATA_SRV/", false);
      this.getView().byId("filter_dept")
        .setModel(this.oProductsModel_dept);
      var aCols = oColModel.getData()
        .cols;
      this._oValueHelpDialog_dept = sap.ui.xmlfragment("com.zbuyer.ZBUYER_PULL.view.valuehelp_dept", this);
      this.getView()
        .addDependent(this._oValueHelpDialog_dept);
      var val_dept = this._oValueHelpDialog_dept.getTable();
        //.then(function (oTable) {
          val_dept.setModel(this.oProductsModel_dept);
          val_dept.setModel(oColModel, "columns");
          if (val_dept.bindRows) {
            val_dept.bindAggregation("rows", "/YshDeptSet");
          }
          if (val_dept.bindItems) {
            val_dept.bindAggregation("items", "/YshDeptSet", function () {
              return new ColumnListItem({
                cells: aCols.map(function (column) {
                  return new Label({
                    text: "{" + column.template + "}"
                  });
                })
              });
            });
          }
          this._oValueHelpDialog_dept.update();
      //  }.bind(this));
      this._oValueHelpDialog_dept.setTokens([
        new Token({
          key: this._oInput_dept.getSelectedKey(),
          text: this._oInput_dept.getValue()
        })
      ]);
      this._oValueHelpDialog_dept.open();
    },
    onValueHelpOkPress_dept: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput_dept.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog_dept.close();
    },
    selectionchange_dept: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput_dept.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog_dept.close();
    },
    onValueHelpCancelPress_dept: function () {
      this._oValueHelpDialog_dept.close();
    },
    onValueHelpAfterClose_dept: function () {
      this._oValueHelpDialog_dept.destroy();
    },

    ////// dept search help ends&nbsp;

    ///////lgort search help start
    onValueHelpRequested_lgort: function () {
      var oColModel = this.getOwnerComponent()
        .getModel("lgort_col");
      this.oProductsModel_lgort = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BP_SEARCH_HELP_ODATA_SRV/", false);
      this.getView().byId("filter_lgort")
        .setModel(this.oProductsModel_lgort);
      var aCols = oColModel.getData()
        .cols;
      this._oValueHelpDialog_lgort = sap.ui.xmlfragment("com.zbuyer.ZBUYER_PULL.view.valuehelp_lgort", this);
      this.getView()
        .addDependent(this._oValueHelpDialog_lgort);
     var val_lgort =  this._oValueHelpDialog_lgort.getTable();
       // .then(function (oTable) {
          val_lgort.setModel(this.oProductsModel_lgort);
          val_lgort.setModel(oColModel, "columns");
          if (val_lgort.bindRows) {
            val_lgort.bindAggregation("rows", "/YshDeptSet");
          }
          if (val_lgort.bindItems) {
            val_lgort.bindAggregation("items", "/YshDeptSet", function () {
              return new ColumnListItem({
                cells: aCols.map(function (column) {
                  return new Label({
                    text: "{" + column.template + "}"
                  });
                })
              });
            });
          }
          this._oValueHelpDialog_lgort.update();
        //}.bind(this));
      this._oValueHelpDialog_lgort.setTokens([
        new Token({
          key: this._oInput_lgort.getSelectedKey(),
          text: this._oInput_lgort.getValue()
        })
      ]);
      this._oValueHelpDialog_lgort.open();
    },
    onValueHelpOkPress_lgort: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput_lgort.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog_lgort.close();
    },
    selectionchange_lgort: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput_lgort.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog_lgort.close();
    },
    onValueHelpCancelPress_lgort: function () {
      this._oValueHelpDialog_lgort.close();
    },
    onValueHelpAfterClose_lgort: function () {
      this._oValueHelpDialog_lgort.destroy();
    },
    ///// lgort search help end&nbsp;

    ///////vendor search help start
    onValueHelpRequested_vendor: function () {
      var oColModel = this.getOwnerComponent()
        .getModel("vendor_col");
      this.oProductsModel_vendor = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BP_SEARCH_HELP_ODATA_SRV/", false);
      this.getView().byId("filter_vendor")
        .setModel(this.oProductsModel_vendor);
      var aCols = oColModel.getData()
        .cols;
      this._oValueHelpDialog_vendor = sap.ui.xmlfragment("com.zbuyer.ZBUYER_PULL.view.valuehelp_vendor", this);
      this.getView()
        .addDependent(this._oValueHelpDialog_vendor);
     var val_vendor =  this._oValueHelpDialog_vendor.getTableAsync()
        //.then(function (oTable) {
          val_vendor.setModel(this.oProductsModel_vendor);
          val_vendor.setModel(oColModel, "columns");
          if (val_vendor.bindRows) {
            val_vendor.bindAggregation("rows", "/GhoVendorShlpSet");
          }
          if (val_vendor.bindItems) {
            val_vendor.bindAggregation("items", "/GhoVendorShlpSet", function () {
              return new ColumnListItem({
                cells: aCols.map(function (column) {
                  return new Label({
                    text: "{" + column.template + "}"
                  });
                })
              });
            });
          }
          this._oValueHelpDialog_vendor.update();
      //  }.bind(this));
      /*   this._oValueHelpDialog_vendor.setTokens([
           new Token({
             key: this._oInput_vendor.getSelectedKey(),
             text: this._oInput_vendor.getValue()
           })
         ]);*/
      this._oValueHelpDialog_vendor.setTokens(this._oInput_vendor.getTokens());
      this._oValueHelpDialog_vendor.open();
    },
    onValueHelpOkPress_vendor: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      // this._oInput_vendor.setSelectedKey(aTokens[0].getKey());
      this._oInput_vendor.setTokens(aTokens);
      this._oValueHelpDialog_vendor.close();
    },
    selectionchange_vendor: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput_vendor.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog_vendor.close();
    },
    onValueHelpCancelPress_vendor: function () {
      this._oValueHelpDialog_vendor.close();
    },
    onValueHelpAfterClose_vendor: function () {
      this._oValueHelpDialog_vendor.destroy();
    },
    ///// vendor search help end&nbsp;

    ///////site group search help start
    onValueHelpRequested_site: function () {
      var oColModel = this.getOwnerComponent()
        .getModel("sitegroup_col");
      this.oProductsModel_sitegroup = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BP_SEARCH_HELP_ODATA_SRV/", false);
      this.getView().byId("filter_sitegroup")
        .setModel(this.oProductsModel_sitegroup);
      var aCols = oColModel.getData()
        .cols;
      this._oValueHelpDialog_sitegroup = sap.ui.xmlfragment("com.zbuyer.ZBUYER_PULL.view.valuehelp_sitegroup", this);
      this.getView()
        .addDependent(this._oValueHelpDialog_sitegroup);
      var val_site = this._oValueHelpDialog_sitegroup.getTable();
       // .then(function (oTable) {
          val_site.setModel(this.oProductsModel_sitegroup);
          val_site.setModel(oColModel, "columns");
          if (val_site.bindRows) {
            val_site.bindAggregation("rows", "/YshSiteGroupSet");
          }
          if (val_site.bindItems) {
            val_site.bindAggregation("items", "/YshSiteGroupSet", function () {
              return new ColumnListItem({
                cells: aCols.map(function (column) {
                  return new Label({
                    text: "{" + column.template + "}"
                  });
                })
              });
            });
          }
          this._oValueHelpDialog_sitegroup.update();
       // }.bind(this));
      this._oValueHelpDialog_sitegroup.setTokens([
        new Token({
          key: this._oInput_sitegroup.getSelectedKey(),
          text: this._oInput_sitegroup.getValue()
        })
      ]);
      this._oValueHelpDialog_sitegroup.open();
    },
    onValueHelpOkPress_sitegroup: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput_sitegroup.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog_sitegroup.close();
    },
    selectionchange_sitegroup: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput_sitegroup.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog_sitegroup.close();
    },
    onValueHelpCancelPress_sitegroup: function () {
      this._oValueHelpDialog_sitegroup.close();
    },
    onValueHelpAfterClose_sitegroup: function () {
        this._oValueHelpDialog_sitegroup.destroy();
      }
      ///// sitegroup search help end&nbsp;

  });
});