sap.ui.define([
	"buyer/SAP_buyer/test/unit/controller/View1.controller"
], function () {
	"use strict";
});