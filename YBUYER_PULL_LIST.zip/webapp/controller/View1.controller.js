sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/ColumnListItem",
	"sap/m/Label",
	"sap/m/Token",
	"sap/m/MessageToast"
], function (Controller, JSONModel, ColumnListItem, Label, Token, MessageToast) {
	"use strict";
	return Controller.extend("com.zbuyer.ZBUYER_PULL.controller.View1", {
		onInit: function () {
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BUYER_PULL_LIST_ODATA_SRV/", false);
			var oView = this.getView();
			oView.setModel(oModel);
			this._oInput = this.getView()
				.byId("filter_werks");
			this._oInput_mat = this.getView()
				.byId("filter_matnr");
			this._oInput_ekg = this.getView()
				.byId("filter_ekgrp");
			var selectModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BP_SEARCH_HELP_ODATA_SRV/", false);
			var selectId = this.getView().byId("idCode1");
			selectId.setModel(selectModel);
			//this.getView().byId("idCode1").setModel(this.getOwnerComponent().getModel("deposition_code"));
			// var dataModel = this.getOwnerComponent()
			//   .getModel("deposition_code");
			// this.getView()
			//  .setModel(dataModel, "DataModel");
		},
		beforeRebindTable: function (oEvent) {
			var oBindingParams = oEvent.getParameter("bindingParams");
			var aFilters = oBindingParams.filters;
			// Create the table object
			var oSmartTable = oEvent.getSource();
			// Get the SmartFilterBarID
			var oSmartFilterBar = this.byId(oSmartTable.getSmartFilterId());
			if (oSmartFilterBar instanceof sap.ui.comp.smartfilterbar.SmartFilterBar) {
				var f_matnr = oSmartFilterBar.getControlByKey("Matnr");
				var fv_matnr = f_matnr.getValue();
				var f_matnr = oSmartFilterBar.getControlByKey("Matnr");
				var fv_matnr = f_matnr.getValue();
				var f_werks = oSmartFilterBar.getControlByKey("Werks");
				var fv_werks = f_werks.getValue();
				var f_ekgrp = oSmartFilterBar.getControlByKey("Ekgrp");
				var fv_ekgrp = f_ekgrp.getValue();
				if (fv_matnr != "") {
					oBindingParams.filters.push(new sap.ui.model.Filter("Matnr", "EQ", fv_matnr));
				}
				if (fv_werks != "") {
					oBindingParams.filters.push(new sap.ui.model.Filter("Werks", "EQ", fv_werks));
				}
				if (fv_ekgrp != "") {
					oBindingParams.filters.push(new sap.ui.model.Filter("Ekgrp", "EQ", fv_ekgrp));
				}
			}
		},
		onExecute: function (oEvent) {
			//get Value from drop down
			var drop_text = this.getView().byId("idCode1").getSelectedItem().getProperty("text");
			var drop_key = this.getView().byId("idCode1").getSelectedItem().getProperty("key");
			//get selected rows from table
			var selectedRow = [];
			var oTable = this.getView()
				.byId("smartTable_ResponsiveTable")
				.getTable();
			var j;
			var oItems = oTable.getSelectedIndices();
			for (var i = 0; i < oItems.length; i++) {
				j = oItems[i];
				var l_ekgrp = oTable.getContextByIndex(j)
					.getProperty("Ekgrp");
				var l_Matnr = oTable.getContextByIndex(j)
					.getProperty("Matnr");
				var l_Werks = oTable.getContextByIndex(j)
					.getProperty("Werks");
				selectedRow.push({
					Matnr: l_Matnr,
					Werks: l_Werks,
					DpCode: drop_key,
					DpCodeDesc: drop_text
				});
			} //for loop ends here
			// now adding header information
			var oEntry1 = {};
			oEntry1.Ekgrp = l_ekgrp;
			oEntry1.HeaderItemSet = selectedRow;
			/*
			//Create and set the Model
			var oUpModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BUYER_PULL_LIST_ODATA_SRV/");
			oUpModel.create("/HeaderItemSet",oEntry1, {
			sucess: function(oData,oResponse)
			{
			MessageToast.show("Records submitted successfully");
			},
			error : function(oError)
			{
			MessageToast.show("Could not Update");
			}
			});
			*/
			var Odatareq = new sap.ui.model.odata.ODataModel();
			Odatareq.request({
					requestUri: "/sap/opu/odata/sap/Y_BUYER_PULL_LIST_ODATA_SRV/HeaderItemSet/",
					method: "GET",
					headers: {
						"X-Requested-With": "XMLHttpRequest",
						"Content-Type": "application/atom+xml",
						"DataServiceVersion": "2.0",
						"X-CSRF-Token": "Fetch"
					}
				},
				function (data, response) {
					header_xcsrf_token = response.headers["x-csrf-token"];
					var oHeaders = {
						"x-csrf-token": header_xcsrf_token,
						"Accept": "application/json",
					};
					ODatareq.request({
							requestUri: "/sap/opu/odata/sap/Y_BUYER_PULL_LIST_ODATA_SRV/HeaderItemSet/",
							method: "POST",
							headers: oHeaders,
							data: oEntry1
						},
						function (data, request) {
							MessageToast.show("Records submitted successfully");
							location.reload(true);
						},
						function (err) {
							MessageToast.show("Could not Update");
						});
				},
				function (err) {
					var request = err.request;
					var response = err.response;
				});
			/*
      var oButton2 = new sap.m.Button("Save", {
        text: "Save",
        type: sap.m.ButtonType.Accept,
        press: function () {
          this.Save(oEvent);
        }
      });
      var oButton3 = new sap.m.Button("Cancel", {
        text: "Cancel",
        type: sap.m.ButtonType.Reject,
        tap: function () {
        Controller.Cancel(oEvent);
        }
      });
      var oDialog = new sap.m.Dialog("Dialog1", {
        title: "Detailed Reason",
        contentWidth: "3em",
        buttons: [oButton2, oButton3],
        content: [
          new sap.m.Label({
            text: "Reason"
          }),
          new sap.m.Input({
            maxLength: 100,
            id: "reason"
          })
        ]
      });
      sap.ui.getCore()
        .byId("Dialog1")
        .open();
    },
    Save: function (oEvent) {
      var fName = sap.ui.getCore()
        .byId("reason")
        .getValue();
      alert(fName);
    },
    Cancel: function (oEvent) {
      sap.ui.getCore()
        .byId("Dialog1")
        .close();
      this.getView()
        .byId("Dialog1")
        .close(); */
			//MessageToast.show("Records submitted successfully");
		},
		onValueHelpRequested_matnr: function () {
			var oColModel = this.getOwnerComponent()
				.getModel("matnr_col");
			this.oProductsModel_mat = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BP_SEARCH_HELP_ODATA_SRV/", false);
			this.getView().byId("filter_matnr")
				.setModel(this.oProductsModel_mat);
			var aCols = oColModel.getData()
				.cols;
			this._oValueHelpDialog_mat = sap.ui.xmlfragment("com.zbuyer.ZBUYER_PULL.view.valuehelp_matnr", this);
			this.getView()
				.addDependent(this._oValueHelpDialog_mat);
			this._oValueHelpDialog_mat.getTableAsync()
				.then(function (oTable) {
					oTable.setModel(this.oProductsModel_mat);
					oTable.setModel(oColModel, "columns");
					if (oTable.bindRows) {
						oTable.bindAggregation("rows", "/CbglwiMatnrESet");
					}
					if (oTable.bindItems) {
						oTable.bindAggregation("items", "/CbglwiMatnrESet", function () {
							return new ColumnListItem({
								cells: aCols.map(function (column) {
									return new Label({
										text: "{" + column.template + "}"
									});
								})
							});
						});
					}
					this._oValueHelpDialog_mat.update();
				}.bind(this));
			this._oValueHelpDialog_mat.setTokens([
				new Token({
					key: this._oInput_mat.getSelectedKey(),
					text: this._oInput_mat.getValue()
				})
			]);
			this._oValueHelpDialog_mat.open();
		},
		onValueHelpOkPress_mat: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this._oInput_mat.setSelectedKey(aTokens[0].getKey());
			this._oValueHelpDialog_mat.close();
		},
		selectionchange_mat: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this._oInput_mat.setSelectedKey(aTokens[0].getKey());
			this._oValueHelpDialog_mat.close();
		},
		onValueHelpCancelPress_mat: function () {
			this._oValueHelpDialog_mat.close();
		},
		onValueHelpAfterClose_mat: function () {
			this._oValueHelpDialog_mat.destroy();
		},
		////value help request matnr ends///////&nbsp;&nbsp;&nbsp;
		///////////////////////plue help request werks start////
		onValueHelpRequested_werks: function () {
			var oColModel = this.getOwnerComponent()
				.getModel("werks_col");
			this.oProductsModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BP_SEARCH_HELP_ODATA_SRV/", false);
			this.getView().byId("filter_werks")
				.setModel(this.oProductsModel);
			var aCols = oColModel.getData()
				.cols;
			this._oValueHelpDialog = sap.ui.xmlfragment("com.zbuyer.ZBUYER_PULL.view.valuehelp_werks", this);
			this.getView()
				.addDependent(this._oValueHelpDialog);
			this._oValueHelpDialog.getTableAsync()
				.then(function (oTable) {
					oTable.setModel(this.oProductsModel);
					oTable.setModel(oColModel, "columns");
					if (oTable.bindRows) {
						oTable.bindAggregation("rows", "/MdgBsMatWerksElemSet");
					}
					if (oTable.bindItems) {
						oTable.bindAggregation("items", "/MdgBsMatWerksElemSet", function () {
							return new ColumnListItem({
								cells: aCols.map(function (column) {
									return new Label({
										text: "{" + column.template + "}"
									});
								})
							});
						});
					}
					this._oValueHelpDialog.update();
				}.bind(this));
			this._oValueHelpDialog.setTokens([
				new Token({
					key: this._oInput.getSelectedKey(),
					text: this._oInput.getValue()
				})
			]);
			this._oValueHelpDialog.open();
		},
		onValueHelpOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this._oInput.setSelectedKey(aTokens[0].getKey());
			this._oValueHelpDialog.close();
		},
		selectionchange: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this._oInput.setSelectedKey(aTokens[0].getKey());
			this._oValueHelpDialog.close();
		},
		onValueHelpCancelPress: function () {
			this._oValueHelpDialog.close();
		},
		onValueHelpAfterClose: function () {
			this._oValueHelpDialog.destroy();
		},
	
		////value help request werks ends///////&nbsp;&nbsp;&nbsp;&nbsp;
		////value help request ekgrp start //////&nbsp;
		onValueHelpRequested_ekgrp: function () {
			var oColModel = this.getOwnerComponent()
				.getModel("ekgrp_col");
			this.oProductsModel_ekg = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Y_BP_SEARCH_HELP_ODATA_SRV/", false);
			this.getView().byId("filter_ekgrp")
				.setModel(this.oProductsModel_ekg);
			var aCols = oColModel.getData()
				.cols;
			this._oValueHelpDialog_ekg = sap.ui.xmlfragment("com.zbuyer.ZBUYER_PULL.view.valuehelp_ekgrp", this);
			this.getView()
				.addDependent(this._oValueHelpDialog_ekg);
			this._oValueHelpDialog_ekg.getTableAsync()
				.then(function (oTable) {
					oTable.setModel(this.oProductsModel_ekg);
					oTable.setModel(oColModel, "columns");
					if (oTable.bindRows) {
						oTable.bindAggregation("rows", "/GhoVendorShlpSet");
					}
					if (oTable.bindItems) {
						oTable.bindAggregation("items", "/GhoVendorShlpSet", function () {
							return new ColumnListItem({
								cells: aCols.map(function (column) {
									return new Label({
										text: "{" + column.template + "}"
									});
								})
							});
						});
					}
					this._oValueHelpDialog_ekg.update();
				}.bind(this));
			this._oValueHelpDialog_ekg.setTokens([
				new Token({
					key: this._oInput_ekg.getSelectedKey(),
					text: this._oInput_ekg.getValue()
				})
			]);
			this._oValueHelpDialog_ekg.open();
		},
		onValueHelpOkPress_ekg: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this._oInput_ekg.setSelectedKey(aTokens[0].getKey());
			this._oValueHelpDialog_ekg.close();
		},
		selectionchange_ekg: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this._oInput_ekg.setSelectedKey(aTokens[0].getKey());
			this._oValueHelpDialog_ekg.close();
		},
		onValueHelpCancelPress_ekg: function () {
			this._oValueHelpDialog_ekg.close();
		},
		onValueHelpAfterClose_ekg: function () {
			this._oValueHelpDialog_ekg.destroy();
		} 
	});
});