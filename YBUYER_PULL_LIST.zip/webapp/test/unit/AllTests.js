sap.ui.define([
	"com/costco/buyerlist/YBUYER_PULL_LIST/test/unit/controller/View1.controller"
], function () {
	"use strict";
});