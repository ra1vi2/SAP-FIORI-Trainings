/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/costco/buyerlist/YBUYER_PULL_LIST/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});