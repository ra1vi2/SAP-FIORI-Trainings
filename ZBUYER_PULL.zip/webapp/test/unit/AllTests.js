sap.ui.define([
	"com/zbuyer/ZBUYER_PULL/test/unit/controller/View1.controller"
], function () {
	"use strict";
});