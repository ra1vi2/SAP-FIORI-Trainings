sap.ui.define([
	"com/sopra/smart/sopra_smart_table/test/unit/controller/View1.controller"
], function () {
	"use strict";
});