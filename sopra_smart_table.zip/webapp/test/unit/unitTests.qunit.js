/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/sopra/smart/sopra_smart_table/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});