sap.ui.define([
	"sap/ui/core/Control"
], function (Control) {
	"use strict";
	return Control.extend("customControl.CustomControl.custom.Label_Input", {
		metadata : {
			properties:{
				"width":{
					type:"sap.ui.core.CSSSize",
					defaultValue: "15em"
				},
				"height":
				{
						type:"sap.ui.core.CSSSize",
					defaultValue: "5em"
				}
			},
			aggregations:{
				_label:{
					type:"sap.m.Label",
					multiple: false
				},
				_input:{
					type:"sap.m.Input",
					multiple: false
				}
			},
			events:{
				"hover":{}
			}
		},
		onmouseover:function(evt)
		{
			this.fireHover();
		},
		init : function () {
				this.setAggregation("_label", new sap.m.Label({
				text: "Label"
			}).addStyleClass("sapUiTinyMargin"));
			
			this.setAggregation("_input", new sap.m.Input({
			}));
		},
		renderer : function (oRM, oControl) {
			oRM.write("<div");
			oRM.addStyle("width",oControl.getProperty("width"));
			oRM.addStyle("height",oControl.getProperty("height"));
			oRM.writeStyles();
			oRM.writeControlData(oControl);
			oRM.addClass("myControl");
			oRM.writeClasses();
			oRM.write(">");
			oRM.renderControl(oControl.getAggregation("_label"));
			oRM.renderControl(oControl.getAggregation("_input"));
			oRM.write("</div>");

		}
	});
});
