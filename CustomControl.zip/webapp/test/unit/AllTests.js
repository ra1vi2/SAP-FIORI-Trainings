sap.ui.define([
	"customControl/CustomControl/test/unit/controller/View1.controller"
], function () {
	"use strict";
});