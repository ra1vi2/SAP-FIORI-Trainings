sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("customControl.CustomControl.controller.View1", {
		onInit: function () {

		},
		mousehover:function(){alert("mouse hover");}
		handleIconTabBarSelect: function (oEvent) {
		
			if (sKey === "Ok") {
				
			}
		}
	});
});