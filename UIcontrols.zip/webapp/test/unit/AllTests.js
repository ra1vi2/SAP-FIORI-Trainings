sap.ui.define([
	"com/UIcontrols/test/unit/controller/View1.controller"
], function () {
	"use strict";
});