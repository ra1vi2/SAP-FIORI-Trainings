sap.ui.define([], function() {
	"use strict";
	return {
		formatValue : function(sValue) {
			//var chartform = new sap.viz.ui5.format.ChartFormatter();
			
			var fValue = sValue.charAt(0);
			
			return fValue+"M" ;
		}
	};
});
