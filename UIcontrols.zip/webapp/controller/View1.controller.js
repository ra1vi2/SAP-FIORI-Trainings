sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/UIcontrols/model/formatter",
	"sap/viz/ui5/format/ChartFormatter",
"sap/viz/ui5/api/env/Format"
], function (Controller,formatter,ChartFormatter,Format) {
	"use strict";

	return Controller.extend("com.UIcontrols.controller.View1", {
		formatter : formatter,  
		onInit: function () {
            
            var data = {
            	Items: [
            		{
            			dime: "Dimeansion 1",
            			meas: 5000000
            		},
            		{
            			dime: "Dimeansion 2",
            			meas: 7000000
            		},
            		{
            			dime: "Dimeansion 3",
            			meas: 8000000
            		},
            		{
            			dime: "Dimeansion 4",
            			meas: 3000000
            		}
            		
            		]
            } ;
            
           var jModel = new sap.ui.model.json.JSONModel();
           jModel.setData(data);
           this.getView().setModel(jModel,"model");

          var oChart = this.getView().byId("idPieChart");
          var oChartProp = oChart.getVizProperties();
          var  oColor = ["#cca633" , "#5933cc" ,"#cc3359" , "#3333cc"] ;
          oChartProp.plotArea.colorPalette = oColor ;
          
          oChart.setVizProperties(oChartProp);

			var oVizPop = new sap.viz.ui5.controls.Popover({});
	    	oVizPop.connect(oChart.getVizUid());

         this._setCustomFormatter();

		},
		_setCustomFormatter:function(){	
	var chartFormatter = ChartFormatter.getInstance();
	Format.numericFormatter(chartFormatter);
	var UI5_FLOAT_FORMAT = "CustomFloatFormat_F2";
	chartFormatter.registerCustomFormatter(UI5_FLOAT_FORMAT, function(value) {
	var ofloatInstance =  sap.ui.core.format.NumberFormat.getFloatInstance({style: 'short',
					maxFractionDigits: 2});
				return ofloatInstance.format(value);
			});
}
	});
});