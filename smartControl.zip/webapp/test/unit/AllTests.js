sap.ui.define([
	"smartControl/smartControl/test/unit/controller/View1.controller"
], function () {
	"use strict";
});