sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
	
], function (Controller, History, JSON, MessageToast) {
	"use strict";


	return Controller.extend("com.sopra.test.sopra_steria_test.controller.View2", {
	
		onInit: function () {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var rChangeItem = oRouter.getRoute("View1");
			// var oRouter = sap.ui.core.routing.Router.getRouter("appRouter");
             //  oRouter.attachRouteMatched(this._onRouteMatched);
			rChangeItem.attachMatched(this._onRouteMatched, this);
		//	this.flag = 1;
			//  this.getOwnerComponent().getRouter().getRoute("View1").getParameter("text");
		},

onBeforeRendering: function()
{
	//var oRouter = this.getRouter();
	//		oRouter.getRou*/te("View1").attachMatched(this.onObjectMatched, this);

	//this._onRouteMatched();
	
	var oModel = sap.ui.getCore().getModel("local_model");
	//this.getView().byId("text_tst").setText(oModel.getData().key);
	this.getView().byId("detail_mat").setText(oModel.getData().mat);
	this.getView().byId("detail_qty").setText(oModel.getData().qty);
	this.getView().byId("detail_amt").setText(oModel.getData().amt);
	this.getView().byId("detail_so").setText(oModel.getData().salesord);

	if (oModel.getData().status == "0") {
				this.getView().byId("btn_approve").setEnabled(false);
			}
			else
			{
			this.getView().byId("btn_approve").setEnabled(true);	
			}
			
			this.getView().byId("in_mat").setValue("");
			this.getView().byId("in_qty").setValue("");
			this.getView().byId("form0").setVisible(false);
	
},



		_onRouteMatched: function (evt) {

			var argu = evt.getParameter("arguments");
			this.key = argu.key;
			var so_id = argu.salesord;
			var mat = argu.material;
			var qty = argu.qty;
			var amt = argu.amt;
			var status = argu.status;

			if (status == "0") {
				this.getView().byId("btn_approve").setEnabled(false);
			}
			
			var omodel_ = new sap.ui.model.json.JSONModel({
			mat: mat,
			qty: qty,
			amt: amt
		});
		
		var odetform = this.getView().byId("DetailForm");
		odetform.setModel(omodel_,"model_");

			/* var oViewModel = new JSON({material: mat});
  this.getView().byId("inputcheck").setModel(oViewModel,"mat_view");
*/
	/*		var label = new sap.m.Text({
				text: so_id
			});

			this.getView().addContent(label);

			var oForm = this.getView().byId("actionDetailForm");

			var oText = new sap.m.Text({
				text: "Selected Sales Order : " + so_id
			});

			oForm.addContent(oText); 
			
			

			var oForm2 = this.getView().byId("DetailForm");

			var lbl_mat = new sap.m.Label({
				text: "Material  "

			});

			var text_mat = new sap.m.Text({
				text: mat

			});

			var lbl_qty = new sap.m.Label({
				text: "Quantity  "

			});

			var text_qty = new sap.m.Text({
				text: qty

			});

			var lbl_amt = new sap.m.Label({
				text: "Total Amount  "

			});

			var text_amt = new sap.m.Text({
				text: amt

			});

			oForm2.setLayout(sap.ui.layout.form.SimpleFormLayout.ResponsiveLayout);
			oForm2.addContent(lbl_mat);
			oForm2.addContent(text_mat);

			oForm2.addContent(lbl_qty);
			oForm2.addContent(text_qty);

			oForm2.addContent(lbl_amt);
			oForm2.addContent(text_amt);*/

			/*      var oInput = this.getView().byId("inputcheck");
		 oInput.bindElement("/argu");
		  oInput.bindProperty("placeholder", "name");
		  
		  
		  
		  var oVerticalLayout = this.getView().byId('vLayout');
oVerticalLayout.bindElement("/vdetail");
oVerticalLayout.addContent(new Text({text: "{material}"}));
oVerticalLayout.addContent(new Text({text: "{qty}"}));
oVerticalLayout.addContent(new Text({text: "{amt}"}));
*/
/*			var ojson = new sap.ui.model.json.JSONModel();
			ojson.setData(argu);
			this.getView().byId("header0").setModel(argu, "so");*/

			/*this.getView().bindElement({
			path: "/" + this.so_id,
			model: "so_id"
			});*/
			//this.getView().byId("header0").setModel(so_id,"so_id")

		},

		btn_approve: function () {
			//var jsonData = this.getOwnerComponent().getModel("code").getData().code;
			var jsonModel = this.getOwnerComponent().getModel("code");
			var jsonData = jsonModel.getData();

			for (var i = 0; i < jsonData.code.length; i++) {
				if (jsonData.code[i].key == this.key) {
					jsonData.code[i].status = "0";
				}
			}

			jsonModel.setData(jsonData);

			MessageToast.show("Sales Order Approved");
		/*	var form = this.getView().byId("actionDetailForm");
			form.destroyContent();

			var form2 = this.getView().byId("DetailForm");
			form2.destroyContent();*/

			this.onNavBack();

		},
		
		btn_edit: function(){
			
			
				var oModel = sap.ui.getCore().getModel("local_model");
	//this.getView().byId("text_tst").setText(oModel.getData().key);
	this.getView().byId("in_mat").setValue(oModel.getData().mat);
	this.getView().byId("in_qty").setValue(oModel.getData().qty);
			
			
			var detail_form = this.getView().byId("form0");
			detail_form.setVisible(true);
				var jsonModel = this.getOwnerComponent().getModel("status_json");
		     this.getView().byId("idCode1").setModel(jsonModel,"DataModel");
	

		
			
			
		},
		btn_save: function()
		{
			
		
	
			
			
				var jsonModel = this.getOwnerComponent().getModel("code");
			var jsonData = jsonModel.getData();
			
			var new_mat = this.getView().byId("in_mat").getValue();
			var new_qty = this.getView().byId("in_qty").getValue();
			var new_status = this.getView().byId("idCode1").getSelectedItem().getProperty("key");

			for (var i = 0; i < jsonData.code.length; i++) {
				if (jsonData.code[i].key == this.key) {
					jsonData.code[i].status = new_status;
					jsonData.code[i].matnr = new_mat;
					jsonData.code[i].qty = new_qty;
					
					
				}
			}

			jsonModel.setData(jsonData);

			MessageToast.show("Edited Successfully");
		/*	var form = this.getView().byId("actionDetailForm");
			form.destroyContent();

			var form2 = this.getView().byId("DetailForm");
			form2.destroyContent();*/

			this.onNavBack();
		},
		
		
		onNavBack: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if ((sPreviousHash !== undefined) || (sPreviousHash = "")) {
				window.history.go(-1);
			} else {
				/*	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("View2", true;)*/

				this.getOwnerComponent().getRouter().navTo("View2", false);

			}
		}
	});
});