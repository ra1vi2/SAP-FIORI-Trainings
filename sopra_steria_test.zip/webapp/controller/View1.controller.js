sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/ColumnListItem",
	"sap/m/Label",
	"sap/m/Token",
	"sap/ui/model/json/JSONModel"
	
], function (Controller,ColumnListItem,Label,Token,JSON) {
	"use strict";

	return Controller.extend("com.sopra.test.sopra_steria_test.controller.View1", {
	//	formatter: formatter,
		onInit: function () {
        var jsonModel = this.getOwnerComponent().getModel("code");
		this.getView().byId("list1").setModel(jsonModel,"DataModel");
		//sap.ui.getCore().setModel(jsonModel,"code");
		this._oInput_mat = this.getView()
        .byId("input1");
		//console.log("list loaded");
		},
		
	
		
		onListItemPress:function (oEvent)
		{
			var oItem, oCtx;
			oItem = oEvent.getSource();
			
		/*	var collection = this.getOwnerComponent().getModel("code").getData().code;
            var index = $.inArray('123435546', $.map(collection, function(n){
            return n.nr
              }*/
          //this.getView().getModel("machinemodel").getProperty("/collection/"+index )
          
          
        var index =   oEvent.getSource().getBindingContextPath().charAt(oEvent.getSource().getBindingContextPath().length-1);
          
          var jsonModel = this.getOwnerComponent().getModel("code");
          jsonModel.loadData("code",null,false);
          var key = jsonModel.getProperty("/code/" + index + "/key");
        var mat =   jsonModel.getProperty("/code/" + index + "/matnr");
        var qty = jsonModel.getProperty("/code/" + index + "/qty");
        var amt = jsonModel.getProperty("/code/" + index + "/orderAmt");
		var status = 	jsonModel.getProperty("/code/" + index + "/status");
			oCtx = oItem.getTitle();
			//sap.ui.core.UIComponent.getRouterFor(this).navTo("View1",{
		
		var omodel_det = new sap.ui.model.json.JSONModel({
		key: key,
		mat:mat,
		qty:qty,
		amt:amt,
		status:status,
		salesord : oCtx
		});
		
		sap.ui.getCore().setModel(omodel_det,"local_model");
		
		
			this.getOwnerComponent().getRouter().navTo("View1",{
				key : key,
				salesord : oCtx,
				material: mat,
				qty: qty,
				amt:amt,
				status:status
			});
			//this.getOwnerComponent().getRouter().navTo("View1");
		},
		
		handleSearch : function (evt) {
	// create model filter
	var filters = [];
	var query = evt.getSource().getValue(); // for live change
//	var query = evt.getParameter("query"); //for pressing enter, change in view property also 
	if (query && query.length > 0) {
		var filter = new sap.ui.model.Filter("text", sap.ui.model.FilterOperator.Contains, query);
		filters.push(filter);
	}

	// update list binding
	var list = this.getView().byId("list1");
	var binding = list.getBinding("items");
	binding.filter(filters);
},




  onValueHelpRequested: function () {
      var oColModel = this.getOwnerComponent()
        .getModel("so_col");
     // this.oProductsModel = new sap.ui.model.json.JSONModel("code", false);
    this.oProductsModel =   new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZSOCDS_SRV/", false); 
      this.getView().byId("input1")
        .setModel(this.oProductsModel);
      var aCols = oColModel.getData()
        .cols;
      this._oValueHelpDialog = sap.ui.xmlfragment("com.sopra.test.sopra_steria_test.view.valuehelp", this);
      this.getView()
        .addDependent(this._oValueHelpDialog);
       // var mat_help_tab = this._oValueHelpDialog.getTable();
      this._oValueHelpDialog.getTableAsync()
      .then(function (mat_help_tab) {
          mat_help_tab.setModel(this.oProductsModel);
          mat_help_tab.setModel(oColModel, "columns");
          if (mat_help_tab.bindRows) {
            mat_help_tab.bindAggregation("rows", "/SEPM_I_SalesOrder_E");
          }
          if (mat_help_tab.bindItems) {
            mat_help_tab.bindAggregation("items", "/SEPM_I_SalesOrder_E", function () {
              return new ColumnListItem({
                cells: aCols.map(function (column) {
                  return new Label({
                    text: "{" + column.template + "}"
                  });
                })
              });
            });
          }
          this._oValueHelpDialog.update();
        }.bind(this));
      
        this._oValueHelpDialog.setTokens([
          new Token({
            key: this._oInput_mat.getSelectedKey(),
            text: this._oInput_mat.getValue()
          })
        ]);
        
      //this._oValueHelpDialog.setValue(this._oInput_mat.getValue());
   //   this._oInput_mat.setValue(this._oValueHelpDialog.getSelectedKey());
      this._oValueHelpDialog.open();
    },
    onValueHelpOkPress: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
     // this._oInput_mat.setTokens(aTokens);
     this._oInput_mat.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog.close();
    },
    selectionchange: function (oEvent) {
      var aTokens = oEvent.getParameter("tokens");
      this._oInput_mat.setSelectedKey(aTokens[0].getKey());
      this._oValueHelpDialog.close();
    },
    onValueHelpCancelPress: function () {
      this._oValueHelpDialog.close();
    },
    onValueHelpAfterClose: function () {
      this._oValueHelpDialog.destroy();
    }












	});
});