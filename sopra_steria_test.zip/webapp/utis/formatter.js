sap.ui.define([]
	,
	function(){
		return{
			orderAmt: function(orderAmt)
			{
				if(orderAmt !== null)
				{
			var day = orderAmt.substring(0,1);
				var month = orderAmt.substring(2,3);
				var year = orderAmt.substring(4,5);
				
				var dateformat = day + "/" + month + "/" + year ;
				}
			 return dateformat; 
				
			}
		};
	});