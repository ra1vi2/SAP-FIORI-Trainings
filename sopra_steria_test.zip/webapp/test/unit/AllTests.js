sap.ui.define([
	"com/sopra/test/sopra_steria_test/test/unit/controller/View1.controller"
], function () {
	"use strict";
});