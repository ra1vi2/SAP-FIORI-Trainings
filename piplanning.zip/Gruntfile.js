module.exports = function (grunt) {
    'use strict';

    // load grunt plugins
    require('jit-grunt')(grunt, {
        configureProxies: 'grunt-connect-proxy'
    });

    // create config
    grunt.initConfig({

        settings: {
            connect: {
                host: '*',
                port: '9555'
            },
            proxy: {
                host: 'slnxsaps4h07.marc.fr.ssg',
                port: '50000'
            }
        },

        connect: {
            options: {
                hostname: '<%= settings.connect.host %>',
                port: '<%= settings.connect.port %>',
                livereload: 35729,
                middleware: function (connect, options, defaultMiddleware) {
                    var aMiddlewares = [];
                    aMiddlewares.push(require('grunt-connect-proxy/lib/utils').proxyRequest);
                    aMiddlewares.push(defaultMiddleware);
                    return aMiddlewares;
                }
            },
            connectWebapp: {
                options: {
                    base: ['WebContent'],
                    open: true
                }
            },
            proxies: [
                {
                    context: '/resources',
                    host: '<%= settings.proxy.host %>',
                    port: '<%= settings.proxy.port %>',
                    https: false,
                    rewrite: {
                        '/resources': '/sap/public/bc/ui5_ui5/resources'
                    }
                }, {
                    context: '/sap/opu/odata',
                    host: '<%= settings.proxy.host %>',
                    port: '<%= settings.proxy.port %>',
                    changeOrigin: true,
                    https: false
                }
            ]
        },

        watch: {
            options: {
                livereload: true
            },
            watchWebapp: {
                files: ['WebContent/**/*']
            }
        }
    });

    // register serve task
    grunt.registerTask('serve', ['configureProxies:server', 'connect:connectWebapp', 'watch:watchWebapp']);

    // register default task
    grunt.registerTask('default', ['serve']);
};