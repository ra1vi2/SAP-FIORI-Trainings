sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "piBoard/model/formatter"
], function (Controller, Formatter) {
    "use strict";
    return Controller.extend("piBoard.BaseContoller", {
    	
        formatter: Formatter,
        
        onShowHello : function (oEvent) {
            // Shows a native JavaScript alert.
        	alert("Test");
           },
        });
    });
