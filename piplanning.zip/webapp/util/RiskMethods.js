/**
 * ra1vi2
 *File for Risk related Method  
 * 
 */
sap.ui.define([
	"sap/m/MessageToast",
		"sap/m/Dialog",
		"sap/m/Button",
		"sap/m/ButtonType",
		"sap/m/Text",
], function (
	MessageToast,Dialog,Button,ButtonType,Text) {

	"use strict";
	return {

		CreateRisk: function (oView, oDialog, localModel) {

			this._view = oView;
			this._localModel = localModel;

			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(oView.getId(),
					"piBoard.fragment.Create.createRisk", this);
				oView.addDependent(oDialog);
			}

			//SOC binding
			oDialog.bindElement({
				path: this._view.getModel().createEntry(
					"ETRiskSet", {
						properties: {
							ZProject: this._view.byId("slProject")
								.getSelectedKey(),
							ZProgram: this._view.byId("slProgram")
								.getSelectedKey(),
							SprintYear: this._view.byId("slYear")
								.getSelectedKey(),
							SprintMonth: this._view.byId("slMonth")
								.getSelectedKey(),
						}
					}).getPath()
			});

			oDialog.open();

		},

		/**
		 * It is triggered when user adds info for Risk and 
		 * clicks on add Risk. It hits the database is added 
		 * in the visible info for Risk on the screen
		 */
		onAddRisk: function (oEvent) {
			if (this._checkInputRisk() === true) {
				if (this._view.getModel().hasPendingChanges()) {
					this._view.getModel().submitChanges({
						success: function (oODataBatch) {
							const msg = 'Risk Info is added';
							MessageToast.show(msg);
							//this._view.byId("idRiskTable")
							//	.refreshAggregation("items");
							this._view.byId("idRiskTable").getBinding("items").refresh();
						}.bind(this)
					});
				}
				this._view.byId("createRiskId").close();
			}
		},

		/**
		 * It checks if the mandatory fields are not empty
		 * before adding Risk info
		 */
		_checkInputRisk: function () {
			if (this._view.byId("riskId").getValue() === "") {
				this._view.byId("riskId").setValueState(
					sap.ui.core.ValueState.Error);
				this._view.byId("riskId").setValueStateText(
					"Mandatory Field");
				return false;
			} else if (this._view.byId("riskSelectId").getSelectedKey() === "S") {
				this._view.byId("riskSelectId").setValueState(
					sap.ui.core.ValueState.Error);
				this._view.byId("riskSelectId").setValueStateText(
					"Mandatory Field");
				return false;
			} else if (this._view.byId("riskTypeId").getSelectedKey() === "S") {
				this._view.byId("riskTypeId").setValueState(
					sap.ui.core.ValueState.Error);
				this._view.byId("riskTypeId").setValueStateText(
					"Mandatory Field");
				return false;
			} else {
				return true;
			}
		},
		
				/**
			 * Triggered when close button is clicked
			 */
			onCloseRisk: function (oEvent) {
				if (this._view.getModel().hasPendingChanges()) {
					this._view.getModel().resetChanges();
					this._view.byId("createRiskId").close();

				}
			},
			
				
			/**
			 * set the list and filters to the default value
			 */
			onAfterCloseDialogRisk: function () {
				let oView = this.getView();
				//clears the search text in the list
				if (this._view.byId("riskId")) {
					if (this._view.byId("riskId").getValue() !== "") {
						this._view.byId("riskId").setValue("");
					}
				}

				if (this._view.byId("actionId")) {
					if (this._view.byId("actionId").getValue() !== "") {
						this._view.byId("actionId").setValue("");
					}
				}

				if (this._view.byId("riskSelectId")) {
					if (this._view.byId("riskSelectId").getSelectedKey() !== "S") {
						this._view.byId("riskSelectId").setSelectedKey("S");
					}
				}

				if (this._view.byId("riskTypeId")) {
					if (this._view.byId("riskTypeId").getSelectedKey() !== "S") {
						this._view.byId("riskTypeId").setSelectedKey("S");
					}
				}
			},


		handleDelete: function (oView, oEvent) {
			var that = this;
			var oTable = oView.byId("idRiskTable"),
				oItem = oEvent.getParameter("listItem").getBindingContext();
			var sPath = oItem.getPath();
			var oEntry = {};
			
			let oDialog = new Dialog({
				title: 'Confirm',
				type: 'Message',
				content: new Text({
					text: 'Are you sure you want to delete?'
				}),
				beginButton: new Button({
					type: ButtonType.Emphasized,
					text: 'Delete',
					press: function () {
						var oTable = oView.byId("idRiskTable");
						// after deletion put the focus back to the list
						oTable.attachEventOnce("updateFinished", oTable.focus, oTable);
						// send a delete request to the odata service
						oTable.getModel().remove(sPath);
						oTable.getBinding("items").refresh();
						MessageToast.show("Row Deleted Successfully");

						oDialog.close();
					}
				}),
				endButton: new Button({
					text: 'Cancel',
					press: function () {
						oDialog.close();
					}
				}),
				afterClose: function () {
					oDialog.destroy();
				}
			});

			oDialog.open();

		},
		
	/**
	 * for edit in each row 
	 */
	 
	 	onEditLine: function (oEvent,oView) {
				var oItem = oEvent.getSource().getParent();
				var oTable = oView.byId("idRiskTable");
				var oIndex = oTable.indexOfItem(oItem);

				var oModel = sap.ui.getCore().getModel("oEditFlagModel");
				var oFlag = oModel.getProperty("/oIndex");
				if (oFlag === undefined) {
					oModel.setProperty("/oIndex", oIndex);
					//this.onPress(oItem, true);
					this.onPress2(oItem, true);

				} else {
					var oPreviousItem = oTable.getItems()[oFlag];
					//this.onPress(oPreviousItem, false);
					this.onPress2(oPreviousItem, false);
					var oCurrentItem = oTable.getItems()[oIndex];
					oModel.setProperty("/oIndex", oIndex);
					//this.onPress(oCurrentItem, true);
					this.onPress2(oCurrentItem, true);
				}
			},
			
			onPress2: function (oItem, oFlag) {
				var oEditableCells = oItem.getCells();
				$(oEditableCells).each(function (i) {
					var oEditableCell = oEditableCells[i];
					var oMetaData = oEditableCell.getMetadata();
					var oElement = oMetaData.getElementName();
					if (oElement == "sap.m.Input") {
					//	if (i !== 1) {
							oEditableCell.setEditable(oFlag);
						//}
					}
				});
			},

			onSaveAllLine: function (oEvent,oView) {

				if (oView.getModel().hasPendingChanges()) {
					var oGlobalBusyDialog = new sap.m.BusyDialog();
					oGlobalBusyDialog.open();
					oView.byId("idRiskTable").getModel().submitChanges({
						success: function (oODataBatch) {
							const msg = 'Saved Successfully';
							MessageToast.show(msg);
							oView.byId("idRiskTable")
								.refreshAggregation("items");

							var length = oView.byId("idRiskTable").getItems().length;
							for (var i = 0; i < length; i++) {
								var oEditableCells = oView.byId("idRiskTable").getItems()[i].getCells();
								$(oEditableCells).each(function (i) {
									var oEditableCell = oEditableCells[i];
									var oMetaData = oEditableCell.getMetadata();
									var oElement = oMetaData.getElementName();
									if (oElement == "sap.m.Input") {
										if (i !== 1) {
											oEditableCell.setEditable(false);
										}
									}
								});

							}
							oGlobalBusyDialog.close();
						}.bind(this) ,
						error: function(oError)
						{
							oGlobalBusyDialog.close();
							const msg = 'Error in Saving';
							MessageToast.show(msg);
								
						}
					});
					
				}
			},


	};
});