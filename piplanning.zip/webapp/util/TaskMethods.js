/**
 * ra1vi2
*File for Task related Method  
* 
 */
sap.ui.define([
	"sap/m/MessageToast"
	], function (
		MessageToast) {
	
	"use strict";
	return {
		CreateTask: function (oView, oDialog, localModel) {
			this._view = oView;
			this._localModel = localModel;
			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(oView.getId(),
					"piBoard.fragment.Create.createTask", this);
				oView.addDependent(oDialog);
			}

			oDialog.bindElement({
				path: oView.getModel().createEntry(
					"ETTaskSet", {
						properties: {
							ZProject: oView.byId("slProject")
								.getSelectedKey(),
							ZProgram: oView.byId("slProgram")
								.getSelectedKey(),
							SprintYear: oView.byId("slYear")
								.getSelectedKey(),
							SprintMonth: oView.byId("slMonth")
								.getSelectedKey(),
						}
					}).getPath()
			});

			oDialog.open();

			this._dialog = oDialog;
		},
			/**
			 * It is triggered when user adds info for Task and 
			 * clicks on add Task. It hits the database is added 
			 * in the visible info for task on the screen
			 */
		onAddTask: function (oEvent) {
			if (this._checkInputTask() === true) {
				if (this._view.getModel().hasPendingChanges()) {
					this._view.getModel().submitChanges({
						success: function (oODataBatch) {
							var msg = 'Task ' + oODataBatch.__batchResponses[0].__changeResponses[0].data.TaskId + ' is created';
							MessageToast.show(msg);
							//ra1vi2	//	this.getView().byId("idTaskTable")
							//ra1vi2		//	.refreshAggregation("items"); 
							this._view.byId("idTaskTable").getBinding("items").refresh();
						}.bind(this)
					});
				}
				this._localModel.setProperty("/enableFlag", false);
				this._view.byId("createTaskId").close();

			}
		},
		
			/**
			 * It checks if the mandatory fields are not empty
			 * before adding task info
			 */
		_checkInputTask: function () {
			if (this._view.byId("TaskDescId").getValue() === "") {
				this._view.byId("TaskDescId").setValueState(
					sap.ui.core.ValueState.Error);
				this._view.byId("TaskDescId").setValueStateText(
					"Mandatory Field");
				return false;
			} else {
				return true;
			}
		},
		
			/**
			 * Triggered when close button is clicked
			 */
			onCloseTask: function (oEvent) {
				if (this._view.getModel().hasPendingChanges()) {
					this._view.getModel().resetChanges();
					this._localModel.setProperty("/enableFlag", false);
					this._view.byId("createTaskId").close();
				}
			},
			
				/**
			 * set the list and filters to the default value
			 */
			onAfterCloseDialogTask: function () {
				let oView = this.getView();
				//clears the search text in the list
				if (oView.byId("TaskDescId")) {
					if (oView.byId("TaskDescId").getValue() !== "") {
						oView.byId("TaskDescId").setValue("");
					}
				}
				if (oView.byId("depTaskId")) {
					if (oView.byId("depTaskId").getValue() !== "") {
						oView.byId("depTaskId").setValue("");
					}
				}
				if (oView.byId("selectId")) {
					if (oView.byId("selectId").getSelectedKey() !== "S") {
						oView.byId("selectId").setSelectedKey("S");
					}
				}
				if (oView.byId("estimationId")) {
					if (oView.byId("estimationId").getValue() !== "") {
						oView.byId("estimationId").setValue("");
					}
				}
				if (oView.byId("commentsId")) {
					if (oView.byId("commentsId").getValue() !== "") {
						oView.byId("commentsId").setValue("");
					}
				}
			},
			
					/**
			 * 
			 */
			onAfterTaskDialogOpen: function (oEvent) {
				this.getView().byId("programId").setValue(this.getView().byId("slProgram").getSelectedKey());
				this.getView().byId("projectId").setValue(this.getView().byId("slProject").getSelectedKey());
				this.getView().byId("sprintMonthId").setValue(this.getView().byId("slMonth").getSelectedKey());
				this.getView().byId("sprintYearId").setValue(this.getView().byId("slYear").getSelectedKey());
			},


	};
});