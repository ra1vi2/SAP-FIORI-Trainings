 /*File for Capacity related Method  
 * Anil
 */
sap.ui.define([
	"sap/m/MessageToast",
		"sap/m/Dialog",
		"sap/m/Button",
		"sap/m/ButtonType"
], function (
	MessageToast,Dialog,Button,ButtonType) {
	"use strict";
	return{
		
	/**
	 * for edit in each row 
	 */
	 
	 	onEditLine: function (oEvent,oView) {
				var oItem = oEvent.getSource().getParent();
				var oTable = oView.byId("idMilestoneTable");
				var oIndex = oTable.indexOfItem(oItem);

				var oModel = sap.ui.getCore().getModel("oEditFlagModel");
				var oFlag = oModel.getProperty("/oIndex");
				if (oFlag === undefined) {
					oModel.setProperty("/oIndex", oIndex);
					//this.onPress(oItem, true);
					this.onPress2(oItem, true);

				} else {
					var oPreviousItem = oTable.getItems()[oFlag];
					//this.onPress(oPreviousItem, false);
					this.onPress2(oPreviousItem, false);
					var oCurrentItem = oTable.getItems()[oIndex];
					oModel.setProperty("/oIndex", oIndex);
					//this.onPress(oCurrentItem, true);
					this.onPress2(oCurrentItem, true);
				}
			},
			
			onPress2: function (oItem, oFlag) {
				var oEditableCells = oItem.getCells();
				$(oEditableCells).each(function (i) {
					var oEditableCell = oEditableCells[i];
					var oMetaData = oEditableCell.getMetadata();
					var oElement = oMetaData.getElementName();
					if (oElement == "sap.m.Input") {
					//	if (i !== 1) {
							oEditableCell.setEditable(oFlag);
						//}
					}
				});
			},
			
			onSaveAllLine: function (oEvent,oView) {

				if (oView.getModel().hasPendingChanges()) {
					var oGlobalBusyDialog = new sap.m.BusyDialog();
					oGlobalBusyDialog.open();
					oView.byId("idMilestoneTable").getModel().submitChanges({
						success: function (oODataBatch) {
							const msg = 'Saved Successfully';
							MessageToast.show(msg);
							oView.byId("idMilestoneTable")
								.refreshAggregation("items");

							var length = oView.byId("idMilestoneTable").getItems().length;
							for (var i = 0; i < length; i++) {
								var oEditableCells = oView.byId("idMilestoneTable").getItems()[i].getCells();
								$(oEditableCells).each(function (i) {
									var oEditableCell = oEditableCells[i];
									var oMetaData = oEditableCell.getMetadata();
									var oElement = oMetaData.getElementName();
									if (oElement == "sap.m.Input") {
										if (i !== 1) {
											oEditableCell.setEditable(false);
										}
									}
								});

							}
							oGlobalBusyDialog.close();
						}.bind(this) ,
						error: function(oError)
						{
							oGlobalBusyDialog.close();
							const msg = 'Error in Saving';
							MessageToast.show(msg);
						}
					});
					
				}
			},
			
		handleDelete: function (oView, oEvent) {
			var that = this;
			var oTable = oView.byId("idMilestoneTable"),
				oItem = oEvent.getParameter("listItem").getBindingContext();
			var sPath = oItem.getPath();
			var oEntry = {};
			
			let oDialog = new Dialog({
				title: 'Confirm',
				type: 'Message',
				content: new sap.m.Text({
					text: 'Are you sure you want to delete?'
				}),
				beginButton: new Button({
					type: ButtonType.Emphasized,
					text: 'Delete',
					press: function () {
						var oTable = oView.byId("idMilestoneTable");
						// after deletion put the focus back to the list
						oTable.attachEventOnce("updateFinished", oTable.focus, oTable);
						// send a delete request to the odata service
						oTable.getModel().remove(sPath);
						oTable.getBinding("items").refresh();
						MessageToast.show("Row Deleted Successfully");

						oDialog.close();
					}
				}),
				endButton: new Button({
					text: 'Cancel',
					press: function () {
						oDialog.close();
					}
				}),
				afterClose: function () {
					oDialog.destroy();
				}
			});

			oDialog.open();
		},	
			
	};
});
