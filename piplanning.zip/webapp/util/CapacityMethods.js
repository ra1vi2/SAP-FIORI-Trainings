/**
 * ra1vi2
 *File for Capacity related Method  
 * 
 */
sap.ui.define([
	"sap/m/MessageToast",
		"sap/m/Dialog",
		"sap/m/Button",
		"sap/m/ButtonType",
], function (
	MessageToast,Dialog,Button,ButtonType) {

	"use strict";
	return {
		
		
			/**
			 * It is triggered when user wants to create a new Capacity
			 * info by clicking on the Create Task button in the footer
			 */
			CreateCapacity: function (oView,oDialog,localModel) {
				this._view = oView;
				
				if (!oDialog) {
					oDialog = sap.ui.xmlfragment(oView.getId(),
						"piBoard.fragment.Create.createCapacity", this);
					oView.addDependent(oDialog);
				}
				//SOC binding
				oDialog.bindElement({
					path: oView.getModel().createEntry(
						"ETCapacitySet", {
							properties: {
								ZProject: oView.byId("slProject")
									.getSelectedKey(),
								ZProgram: oView.byId("slProgram")
									.getSelectedKey(),
								SprintYear: oView.byId("slYear")
									.getSelectedKey(),
								SprintMonth: oView.byId("slMonth")
									.getSelectedKey(),
							}
						}).getPath()
				});

				oDialog.open();
			},


			/**
			 * It is triggered when user adds info for Capacity and 
			 * clicks on add Capacity. It hits the database is added 
			 * in the visible info for Capacity on the screen
			 */
			onAddCapacity: function (oEvent) {
				if (this._checkInputCapacity() === true) {
					if (this._view.getModel().hasPendingChanges()) {
						this._view.getModel().submitChanges({
							success: function (oODataBatch) {
								const msg = 'Capacity Info is added';
								MessageToast.show(msg);
							//	this._view.byId("idCapacityTable")
							//		.refreshAggregation("items");
							this._view.byId("idCapacityTable").getBinding("items").refresh();
							}.bind(this)
						});
					}
					this._view.byId("createCapacityId").close();
				}
			},

			/**
			 * It checks if the mandatory fields are not empty
			 * before adding Capacity info
			 */
			_checkInputCapacity: function () {
				if (this._view.byId("totalId").getValue() === "") {
					this._view.byId("totalId").setValueState(
						sap.ui.core.ValueState.Error);
					this._view.byId("totalId").setValueStateText(
						"Mandatory Field");
					return false;
				} else if (this._view.byId("bufferId").getValue() === "") {
					this._view.byId("bufferId").setValueState(
						sap.ui.core.ValueState.Error);
					this._view.byId("bufferId").setValueStateText(
						"Mandatory Field");
					return false;
				} else if (this._view.byId("remainingId").getValue() === "") {
					this._view.byId("remainingId").setValueState(
						sap.ui.core.ValueState.Error);
					this._view.byId("remainingId").setValueStateText(
						"Mandatory Field");
					return false;
				} else if (this._view.byId("confirmedId").getValue() === "") {
					this._view.byId("confirmedId").setValueState(
						sap.ui.core.ValueState.Error);
					this._view.byId("confirmedId").setValueStateText(
						"Mandatory Field");
					return false;
				} else {
					return true;
				}
			},
			
					/**
			 * Triggered when close button is clicked
			 */
			onCloseCapacity: function (oEvent) {
				if (this._view.getModel().hasPendingChanges()) {
					this._view.getModel().resetChanges();
					this._view.byId("createCapacityId").close();
				}
			},

	/**
			 * set the list and filters to the default value
			 */
			onAfterCloseDialogCapacity: function () {
				//clears the search text in the list
				if (this._view.byId("totalId")) {
					if (this._view.byId("totalId").getValue() !== "") {
						this._view.byId("totalId").setValue("");
					}
				}

				if (this._view.byId("bufferId")) {
					if (this._view.byId("bufferId").getValue() !== "") {
						this._view.byId("bufferId").setValue("");
					}
				}

				if (this._view.byId("remainingId")) {
					if (this._view.byId("remainingId").getValue() !== "") {
						this._view.byId("remainingId").setValue("");
					}
				}

				if (this._view.byId("confirmedId")) {
					if (this._view.byId("confirmedId").getValue() !== "") {
						this._view.byId("confirmedId").setValue("");
					}
				}

				if (this._view.byId("assumptionsId")) {
					if (this._view.byId("assumptionsId").getValue() !== "") {
						this._view.byId("assumptionsId").setValue("");
					}
				}
			},
			
			handleDelete: function (oView, oEvent) {
			var that = this;
			var oTable = oView.byId("idCapacityTable"),
				oItem = oEvent.getParameter("listItem").getBindingContext();
			var sPath = oItem.getPath();
			var oEntry = {};
			
			let oDialog = new Dialog({
				title: 'Confirm',
				type: 'Message',
				content: new sap.m.Text({
					text: 'Are you sure you want to delete?'
				}),
				beginButton: new Button({
					type: ButtonType.Emphasized,
					text: 'Delete',
					press: function () {
						var oTable = oView.byId("idCapacityTable");
						// after deletion put the focus back to the list
						oTable.attachEventOnce("updateFinished", oTable.focus, oTable);
						// send a delete request to the odata service
						oTable.getModel().remove(sPath);
						oTable.getBinding("items").refresh();
						MessageToast.show("Row Deleted Successfully");

						oDialog.close();
					}
				}),
				endButton: new Button({
					text: 'Cancel',
					press: function () {
						oDialog.close();
					}
				}),
				afterClose: function () {
					oDialog.destroy();
				}
			});

			oDialog.open();

		},
		
	/**
	 * for edit in each row 
	 */
	 
	 	onEditLine: function (oEvent,oView) {
				var oItem = oEvent.getSource().getParent();
				var oTable = oView.byId("idCapacityTable");
				var oIndex = oTable.indexOfItem(oItem);

				var oModel = sap.ui.getCore().getModel("oEditFlagModel");
				var oFlag = oModel.getProperty("/oIndex");
				if (oFlag === undefined) {
					oModel.setProperty("/oIndex", oIndex);
					//this.onPress(oItem, true);
					this.onPress2(oItem, true);

				} else {
					var oPreviousItem = oTable.getItems()[oFlag];
					//this.onPress(oPreviousItem, false);
					this.onPress2(oPreviousItem, false);
					var oCurrentItem = oTable.getItems()[oIndex];
					oModel.setProperty("/oIndex", oIndex);
					//this.onPress(oCurrentItem, true);
					this.onPress2(oCurrentItem, true);
				}
			},
			
			onPress2: function (oItem, oFlag) {
				var oEditableCells = oItem.getCells();
				$(oEditableCells).each(function (i) {
					var oEditableCell = oEditableCells[i];
					var oMetaData = oEditableCell.getMetadata();
					var oElement = oMetaData.getElementName();
					if (oElement == "sap.m.Input") {
					//	if (i !== 1) {
							oEditableCell.setEditable(oFlag);
						//}
					}
				});
			},

			onSaveAllLine: function (oEvent,oView) {

				if (oView.getModel().hasPendingChanges()) {
					var oGlobalBusyDialog = new sap.m.BusyDialog();
					oGlobalBusyDialog.open();
					oView.byId("idCapacityTable").getModel().submitChanges({
						success: function (oODataBatch) {
							const msg = 'Saved Successfully';
							MessageToast.show(msg);
							oView.byId("idCapacityTable")
								.refreshAggregation("items");

							var length = oView.byId("idCapacityTable").getItems().length;
							for (var i = 0; i < length; i++) {
								var oEditableCells = oView.byId("idCapacityTable").getItems()[i].getCells();
								$(oEditableCells).each(function (i) {
									var oEditableCell = oEditableCells[i];
									var oMetaData = oEditableCell.getMetadata();
									var oElement = oMetaData.getElementName();
									if (oElement == "sap.m.Input") {
										if (i !== 1) {
											oEditableCell.setEditable(false);
										}
									}
								});

							}
							oGlobalBusyDialog.close();
						}.bind(this) ,
						error: function(oError)
						{
							oGlobalBusyDialog.close();
							const msg = 'Error in Saving';
							MessageToast.show(msg);
								
						}
					});
					
				}
			},
		
	};
});