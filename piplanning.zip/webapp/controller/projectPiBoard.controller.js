sap.ui.define(["piBoard/BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"sap/m/MessageToast",
		"piBoard/model/formatter",
		"sap/m/Dialog",
		"sap/m/Button",
		"sap/m/Text",
		"sap/m/ButtonType",
		"piBoard/util/TaskMethods",
		"piBoard/util/RiskMethods",
		"piBoard/util/CapacityMethods",
		"piBoard/util/MilestoneMethods"
	],
	function (BaseController, JSONModel, Filter, FilterOperator, MessageToast, formatter, Dialog, 
	Button, Text, ButtonType,TaskMethods,RiskMethods,CapacityMethods,MilestoneMethods) {
		"use strict";
		return BaseController.extend("piBoard.controller.projectPiBoard", {
			flag: false,
			// sets all the Models used in the Application
			onInit: function () {
				var oView = this.getView();
				this.getOwnerComponent().getModel("Local").setProperty("/ListFlag", false)
				this.getOwnerComponent().getModel("Local").setProperty("/enableFlag", false)

				/*****
				 *ra1vi2 
				 */
				this.changedIndex = [0];
				var oModel = new JSONModel();
				sap.ui.getCore().setModel(oModel, "oEditFlagModel");

				/*****
				 *ra1vi2 
				 */
			},

			/**
			 * on this Event, we are setting the SMonth and SYear 
			 * by using the current month and year from the system
			 */
			onAfterRendering: function () {
				var oView = this.getView();
				var today = new Date();
				oView.byId("slMonth").setSelectedKey(today.getMonth() + 1);
				oView.byId("slYear").setSelectedKey(today.getFullYear());

				var oUserData = this.getOwnerComponent().getModel("userData");
				oUserData.read("/ETUserSet", {
					success: oData => {
						oView.byId("slProgram").setSelectedKey(oData.results[0].Zprogram);
						const programData = this.getView().getModel("CustoData").getProperty(oView.byId("slProgram").getSelectedItem().getBindingInfo(
							"key").binding.getContext().getPath());
						const oModel = new sap.ui.model.json.JSONModel();
						oModel.setData(programData);
						this.getView().byId("slProject").setModel(oModel, "ProgramData");
						oView.byId("slProject").setSelectedKey(oData.results[0].Zproject);

						// apply search
						this.onSearch();
					}
				});
			},

			/*****
			 *ra1vi2 
			 */

			onEditLine: function (oEvent) {
				var oItem = oEvent.getSource().getParent();
				var oTable = this.getView().byId("idTaskTable");
				var oIndex = oTable.indexOfItem(oItem);

				var oModel = sap.ui.getCore().getModel("oEditFlagModel");
				var oFlag = oModel.getProperty("/oIndex");
				if (oFlag === undefined) {
					oModel.setProperty("/oIndex", oIndex);
					//this.onPress(oItem, true);
					this.onPress2(oItem, true);

				} else {
					var oPreviousItem = oTable.getItems()[oFlag];
					//this.onPress(oPreviousItem, false);
					this.onPress2(oPreviousItem, false);
					var oCurrentItem = oTable.getItems()[oIndex];
					oModel.setProperty("/oIndex", oIndex);
					//this.onPress(oCurrentItem, true);
					this.onPress2(oCurrentItem, true);
				}
			},

			/*   onPress: function(oItem, oFlag) {
			          var oEditableCells = oItem.getCells();
			          this.oFlag = oFlag;
			          oEditableCells.forEach(this.editFunction);
			        },
			        
			        editFunction: function(oEditableCell)
			        {
			        //	var oEditableCell = oEditableCells[i];
			            var oMetaData = oEditableCell.getMetadata();
			            var oElement = oMetaData.getElementName();
			            if (oElement == "sap.m.Input") {
			              oEditableCell.setEditable(true);
			            }
			        },*/

			onPress2: function (oItem, oFlag) {
				var oEditableCells = oItem.getCells();
				$(oEditableCells).each(function (i) {
					var oEditableCell = oEditableCells[i];
					var oMetaData = oEditableCell.getMetadata();
					var oElement = oMetaData.getElementName();
					if (oElement == "sap.m.Input") {
						if (i !== 1) {
							oEditableCell.setEditable(oFlag);
						}
					}
				});
			},

			onSaveAllLine: function (oEvent) {

				if (this.getView().getModel().hasPendingChanges()) {
					var oGlobalBusyDialog = new sap.m.BusyDialog();
					oGlobalBusyDialog.open();
					this.getView().byId("idTaskTable").getModel().submitChanges({
						success: function (oODataBatch) {
							const msg = 'Saved Successfully';
							MessageToast.show(msg);
							this.getView().byId("idTaskTable")
								.refreshAggregation("items");

							var length = this.getView().byId("idTaskTable").getItems().length;
							for (var i = 0; i < length; i++) {
								var oEditableCells = this.getView().byId("idTaskTable").getItems()[i].getCells();
								$(oEditableCells).each(function (i) {
									var oEditableCell = oEditableCells[i];
									var oMetaData = oEditableCell.getMetadata();
									var oElement = oMetaData.getElementName();
									if (oElement == "sap.m.Input") {
										if (i !== 1) {
											oEditableCell.setEditable(false);
										}
									}
								});

							}
							oGlobalBusyDialog.close();
						}.bind(this)
					});
				}

				/*	for (var i = 0; i < this.changedIndex.length; i++) {
						var index = this.changedIndex[i];
						var oTable = this.getView().byId("idTaskTable");
						var TaskId = oTable.getItems()[index].getCells()[1].getValue(); //to fetch EPIC iD 
						//get changed values 
						var ZProject = oTable.getItems()[index].getCells()[0].getValue();
						var TaskDesc = oTable.getItems()[index].getCells()[2].getValue();
						var Estimation = oTable.getItems()[index].getCells()[3].getValue();
						var Comments = oTable.getItems()[index].getCells()[4].getValue();
						var Dependency = oTable.getItems()[index].getCells()[5].getValue();
						var DependTask = oTable.getItems()[index].getCells()[6].getValue();

						var oEntry = {};
						oEntry.ZProject = ZProject;
						oEntry.TaskId = TaskId;
						oEntry.TaskDesc = TaskDesc;
						oEntry.Estimation = Estimation;
						oEntry.Comments = Comments;
						oEntry.Dependency = Dependency;
						oEntry.DependTask = DependTask;
						//ZProgram='ZICN',ZProject='ECO',TaskId='ZICNE00012',SprintMonth='1',SprintYear='2020',Application=''
						var oModel = this.getView().byId("idTaskTable").getModel();
						
						oModel.update("/ETTaskSet", oEntry, {
							  method: "PUT",
							success: function(data) {
								alert("success");
							}
						});
					}*/
			},

			addNewRow: function (oEvent) {
				var month = formatter.formatMonth(this.getView().byId("slMonth")
					.getSelectedKey());
				var proj = this.getView().byId("slProject")
					.getSelectedKey() + " / " + this.getView().byId("slYear")
					.getSelectedKey() + " / " + month;
				var oItem = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Text({
							text: proj
						}),
						new sap.m.Text(),
						new sap.m.Input(),
						new sap.m.Input(),
						new sap.m.Input(),
						new sap.m.Input(),
						new sap.m.Input(),
						new sap.m.Button({
							icon: "sap-icon://edit",
							press: [this.onEditLine, this]
						})

					]
				});

				var oTable = this.byId("idTaskTable");
				oTable.addItem(oItem);

			},
			handleDelete: function (oEvent) {
				var that = this;
				var oTable = that.getView().byId("idTaskTable"),
					oItem = oEvent.getParameter("listItem").getBindingContext();
				var sPath = oItem.getPath();
				var oEntry = {};
				oEntry.del_flag = 'X';
				var oDialog = new Dialog({
					title: 'Confirm',
					type: 'Message',
					content: new Text({
						text: 'Are you sure you want to delete?'
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: 'Delete',
						press: function () {
							var oTable = that.getView().byId("idTaskTable");
							// after deletion put the focus back to the list
							oTable.attachEventOnce("updateFinished", oTable.focus, oTable);

							// send a delete request to the odata service
					
							oTable.getModel().remove(sPath);
							oTable.getBinding("items").refresh();
							MessageToast.show("Row Deleted Successfully");

							oDialog.close();
						}
					}),
					endButton: new Button({
						text: 'Cancel',
						press: function () {
							oDialog.close();
						}
					}),
					afterClose: function () {
						oDialog.destroy();
					}
				});

				oDialog.open();

			},

		onEditLine_Risk: function(oEvent)
		{
			const oView = this.getView();
			var editModel = 	sap.ui.getCore().getModel("oEditFlagModel");
			RiskMethods.onEditLine(oEvent,oView);
		},
		
		onSaveAllLine_Risk:function(oEvent)
		{
			const oView = this.getView();
			RiskMethods.onSaveAllLine(oEvent,oView);
		},

     	handleDelete_risk: function (oEvent) {
			
			const oView = this.getView();
			var localModel = 	this.getOwnerComponent().getModel("Local");
			oDialog = RiskMethods.handleDelete(oView,oEvent);

			},
			/*****
			 *ra1vi2 
			 */

			/**
			 * triggers when user enter values in the filter bar and hits GO button
			 * Refreshes the data to be displayed
			 */
			onSearch: function (oEvent) {
				const aFilter = [];

				aFilter.push(new Filter("ZProject", FilterOperator.EQ, this
					.getView().byId("slProject").getSelectedKey()));
				aFilter.push(new Filter("ZProgram", FilterOperator.EQ, this
					.getView().byId("slProgram").getSelectedKey()));
				aFilter.push(new Filter("SprintYear", FilterOperator.EQ, this
					.getView().byId("slYear").getSelectedKey()));
				aFilter.push(new Filter("SprintMonth", FilterOperator.EQ, this
					.getView().byId("slMonth").getSelectedKey()));

				this._applyFilter(aFilter);
				this.hideFilterButton();

			},

			hideFilterButton: function () {
				if (this.getView().byId("slProject").getSelectedKey() == "S") {
					this.getView().byId("createTask").setVisible(false);
				} else {
					this.getView().byId("createTask").setVisible(true);
					this.flag = true;
				}

			},
			/**
			 * It is triggered when user wants to create a new task
			 * info by clicking on the Create Task button in the footer
			 */
			onClickCreateTask: function (oEvent) {
				const oView = this.getView();
				let oDialog = oView.byId("createTaskId");
			var localModel = 	this.getOwnerComponent().getModel("Local");
			oDialog = TaskMethods.CreateTask(oView,oDialog,localModel);
			},

			/**
			 * It is triggered when user wants to create a new Risk
			 * info by clicking on the Create Task button in the footer
			 */
			onClickCreateRisk: function () {
				const oView = this.getView();
				let oDialog = oView.byId("createRiskId");
			
			var localModel = 	this.getOwnerComponent().getModel("Local");
			oDialog = RiskMethods.CreateRisk(oView,oDialog,localModel);
			},
			
			onClickCreateCapacity: function (oEvent) {
				const oView = this.getView();
				let oDialog = oView.byId("createCapacityId");
			var localModel = 	this.getOwnerComponent().getModel("Local");
			oDialog = CapacityMethods.CreateCapacity(oView,oDialog,localModel);
			},
			
		onEditLine_cap: function(oEvent)
		{
			const oView = this.getView();
			var editModel = 	sap.ui.getCore().getModel("oEditFlagModel");
			CapacityMethods.onEditLine(oEvent,oView);
		},
		
		onSaveAllLine_cap:function(oEvent)
		{
			const oView = this.getView();
			CapacityMethods.onSaveAllLine(oEvent,oView);
		},

     	handleDelete_cap: function (oEvent) {
			
			const oView = this.getView();
			var localModel = 	this.getOwnerComponent().getModel("Local");
			oDialog = CapacityMethods.handleDelete(oView,oEvent);

			},

		onEditLine_mile: function(oEvent)
		{
			const oView = this.getView();
			var editModel = sap.ui.getCore().getModel("oEditFlagModel");
			MilestoneMethods.onEditLine(oEvent,oView);
		},
		
		onSaveAllLine_mile:function(oEvent)
		{
			const oView = this.getView();
			MilestoneMethods.onSaveAllLine(oEvent,oView);
		},
		
		handleDelete_mile: function (oEvent) {
			
			const oView = this.getView();
			var localModel = 	this.getOwnerComponent().getModel("Local");
			oDialog = MilestoneMethods.handleDelete(oView,oEvent);
		},
		
			/**
			 * It is triggered when user wants to create a new Milestone
			 * info by clicking on the Create Task button in the footer
			 */
			onClickCreateMilestone: function () {
				const oView = this.getView();
				let oDialog = oView.byId("createMilestoneId");
				if (!oDialog) {
					oDialog = sap.ui.xmlfragment(oView.getId(),
						"piBoard.fragment.Create.createMilestone", this);
					oView.addDependent(oDialog);
				}

				//SOC binding
				oDialog.bindElement({
					path: this.getView().getModel().createEntry(
						"ETMilestoneSet", {
							properties: {
								ZProject: this.getView().byId("slProject")
									.getSelectedKey(),
								ZProgram: this.getView().byId("slProgram")
									.getSelectedKey(),
								SprintYear: this.getView().byId("slYear")
									.getSelectedKey(),
								SprintMonth: this.getView().byId("slMonth")
									.getSelectedKey(),
							}
						}).getPath()
				});

				oDialog.open();
			},

			/**
			 * It is triggered when user adds info for Milestone and 
			 * clicks on add Milestone. It hits the database is added 
			 * in the visible info for Milestone on the screen
			 */
			onAddMilestone: function (oEvent) {
				if (this._checkInputMilestone() === true) {
					if (this.getView().getModel().hasPendingChanges()) {
						this.getView().getModel().submitChanges({
							success: function (oODataBatch) {
								const msg = 'Milestones Info is added';
								MessageToast.show(msg);
								this.getView().byId("idMilestoneTable")
									.refreshAggregation("items");
							}.bind(this)
						});
					}
					this.getView().byId("createMilestoneId").close();
				}
			},

			/**
			 * It checks if the mandatory fields are not empty
			 * before adding Milestone info
			 */
			_checkInputMilestone: function () {
				if (this.getView().byId("DP1").getValue() === "") {
					this.getView().byId("DP1").setValueState(
						sap.ui.core.ValueState.Error);
					this.getView().byId("DP1").setValueStateText(
						"Mandatory Field");
					return false;
				} else {
					return true;
				}
			},

			/**
			 * To handle the live change on various events
			 * and set their state accordingly
			 */
			handleLiveChange: function (oEvent) {
				var oEvt = oEvent.getSource();
				if (oEvt.getValue().length > 0) {
					oEvt.setValueState(sap.ui.core.ValueState.None);
				}

			},

			/**
			 * To handle the live change on various events
			 * and set their state accordingly
			 */
			handleLiveChangeForSprintDate: function (oEvent) {
				var oEvt = oEvent.getSource();
				if (oEvt.getValue() != "") {
					oEvt.setValueState(sap.ui.core.ValueState.None);
				}

			},
			/**
			 * Triggered when close button is clicked
			 */
			onCloseMilestone: function (oEvent) {
				if (this.getView().getModel().hasPendingChanges()) {
					this.getView().getModel().resetChanges();
					this.getView().byId("createMilestoneId").close();
				}
			},

			/**
			 * set the list and filters to the default value
			 */
			onAfterCloseDialogMilestone: function () {
				let oView = this.getView();
				//clears the search text in the list
				if (oView.byId("DP1")) {
					if (oView.byId("DP1").getValue() !== "") {
						oView.byId("DP1").setValue("");
					}
				}

				if (oView.byId("DP1")) {
					if (oView.byId("DP2").getValue() !== "") {
						oView.byId("DP2").setValue("");
					}
				}

				if (oView.byId("DP3")) {
					if (oView.byId("DP3").getValue() !== "") {
						oView.byId("DP3").setValue("");
					}
				}

				if (oView.byId("DP4")) {
					if (oView.byId("DP4").getValue() !== "") {
						oView.byId("DP4").setValue("");
					}
				}

				if (oView.byId("DP5")) {
					if (oView.byId("DP5").getValue() !== "") {
						oView.byId("DP5").setValue("");
					}
				}

				if (oView.byId("DP6")) {
					if (oView.byId("DP6").getValue() !== "") {
						oView.byId("DP6").setValue("");
					}
				}

				if (oView.byId("DP7")) {
					if (oView.byId("DP7").getValue() !== "") {
						oView.byId("DP7").setValue("");
					}
				}
			},

			/**
			 * project data is dependent on Program data.
			 * So, it is binded together to filter all the projects 
			 * of a particular program
			 */
			onChangeProgram: function (oEvent) {
				const programData = this.getView().getModel("CustoData")
					.getProperty(
						oEvent.getParameter("selectedItem").getBindingInfo(
							"key").binding.getContext().getPath());
				const oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(programData);

				this.getView().byId("slProject").setModel(oModel, "ProgramData");

				//Reset Filter
				const aFilter = [];
				this._applyFilter(aFilter);
				this.getView().byId("createTask").setVisible(false);

			},

			_applyFilter: function (aFilter) {

				// Filter Task
				const oTaskTile = this.getView().byId("idTaskPanel");
				oTaskTile.getBinding("content").filter(aFilter);
				const oTaskList = this.getView().byId("idTaskTable");
				oTaskList.getBinding("items").filter(aFilter);

				// Filter Risk 
				const oRiskTile = this.getView().byId("idRiskPanel");
				oRiskTile.getBinding("content").filter(aFilter);
				const oRiskList = this.getView().byId("idRiskTable");
				oRiskList.getBinding("items").filter(aFilter);

				// Filter Capacity
				const oCapacityTile = this.getView().byId("idCapacityPanel");
				oCapacityTile.getBinding("content").filter(aFilter);
				const oCapacityList = this.getView().byId("idCapacityTable");
				oCapacityList.getBinding("items").filter(aFilter);

				// Filter Milestone
				const oMilestoneTile = this.getView().byId("idMilestonePanel");
				oMilestoneTile.getBinding("content").filter(aFilter);
				const oMilestoneList = this.getView().byId("idMilestoneTable");
				oMilestoneList.getBinding("items").filter(aFilter);
			},

			/**
			 * to enable and disbale buttons on footer according to the icon tab selected
			 */
			onSelectIcon: function (oEvent) {
				if (this.flag === false) {
					this.getView().byId("createTask").setVisible(false);
					this.getView().byId("createRisk").setVisible(false);
					this.getView().byId("createCapacity").setVisible(false);
					this.getView().byId("createMilestone").setVisible(false);
				} else {
					if (oEvent.getParameter("selectedItem").getId() === this.getView().getId() + "--icon1") {
						this.getView().byId("createTask").setVisible(true);
						this.getView().byId("createRisk").setVisible(false);
						this.getView().byId("createCapacity").setVisible(false);
						this.getView().byId("createMilestone").setVisible(false);
					}
					if (oEvent.getParameter("selectedItem").getId() === this.getView().getId() + "--icon2") {
						this.getView().byId("createRisk").setVisible(true);
						this.getView().byId("createTask").setVisible(false);
						this.getView().byId("createCapacity").setVisible(false);
						this.getView().byId("createMilestone").setVisible(false);
					}
					if (oEvent.getParameter("selectedItem").getId() === this.getView().getId() + "--icon3") {
						this.getView().byId("createCapacity").setVisible(true);
						this.getView().byId("createTask").setVisible(false);
						this.getView().byId("createRisk").setVisible(false);
						this.getView().byId("createMilestone").setVisible(false);
					}
					if (oEvent.getParameter("selectedItem").getId() === this.getView().getId() + "--icon4") {
						this.getView().byId("createMilestone").setVisible(true);
						this.getView().byId("createTask").setVisible(false);
						this.getView().byId("createRisk").setVisible(false);
						this.getView().byId("createCapacity").setVisible(false);
					}

				}
			},

			/**
			 * To load all the data for all the projects for a particular sprint and year
			 */
			/*
						onClickLoadAll: function(oEvent) {
							const aFilter = [];
							aFilter.push(new Filter("SprintYear", FilterOperator.EQ, this
									.getView().byId("slYear").getSelectedKey()));
							aFilter.push(new Filter("SprintMonth", FilterOperator.EQ, this
									.getView().byId("slMonth").getSelectedKey()));
							// Filter Task
							const oTaskList = this.getView().byId("idTaskTable");
							oTaskList.getBinding("items").filter(aFilter);
					
							// Filter Risk 
							const oRiskList = this.getView().byId("idRiskTable");
							oRiskList.getBinding("items").filter(aFilter);
					
							// Filter Capacity
							const oCapacityList = this.getView().byId("idCapacityTable");
							oCapacityList.getBinding("items").filter(aFilter);
					
							// Filter Milestone
							const oMilestoneList = this.getView().byId("idMilestoneTable");
							oMilestoneList.getBinding("items").filter(aFilter);
						},*/

	

			/**
			 * 
			 */
			onAfterRiskDialogOpen: function (oEvent) {
				this.getView().byId("programRId").setValue(this.getView().byId("slProgram").getSelectedKey());
				this.getView().byId("projectRId").setValue(this.getView().byId("slProject").getSelectedKey());
				this.getView().byId("sprintMonthRId").setValue(this.getView().byId("slMonth").getSelectedKey());
				this.getView().byId("sprintYearRId").setValue(this.getView().byId("slYear").getSelectedKey());
			},

			/**
			 * 
			 */
			onAfterCapacityDialogOpen: function (oEvent) {
				this.getView().byId("programCId").setValue(this.getView().byId("slProgram").getSelectedKey());
				this.getView().byId("projectCId").setValue(this.getView().byId("slProject").getSelectedKey());
				this.getView().byId("sprintMonthCId").setValue(this.getView().byId("slMonth").getSelectedKey());
				this.getView().byId("sprintYearCId").setValue(this.getView().byId("slYear").getSelectedKey());
			},

			/**
			 * 
			 */
			onAfterMilestoneDialogOpen: function (oEvent) {
				this.getView().byId("programMId").setValue(this.getView().byId("slProgram").getSelectedKey());
				this.getView().byId("projectMId").setValue(this.getView().byId("slProject").getSelectedKey());
				this.getView().byId("sprintMonthMId").setValue(this.getView().byId("slMonth").getSelectedKey());
				this.getView().byId("sprintYearMId").setValue(this.getView().byId("slYear").getSelectedKey());
			},

			/**
			 * 
			 */
			onPressButtonChangeLayout: function (oEvent) {
				if (this.getView().getModel("Local").getProperty("/ListFlag") === true) {
					this.getView().getModel("Local").setProperty("/ListFlag", false)
				} else {
					this.getView().getModel("Local").setProperty("/ListFlag", true)
				}

			},

			enableDependentId: function () {
				if (this.getView().byId("selectId").getSelectedKey() === "Y") {
					this.getView().getModel("Local").setProperty("/enableFlag", true)
				} else {
					this.getView().getModel("Local").setProperty("/enableFlag", false)
				}

			},
			onPressButtonNextMonth: function () {
				const nCurrentMonth = Number(this.getView().byId("slMonth").getSelectedKey());
				if (nCurrentMonth === 12) {
					// Set January and Next year
					this.getView().byId("slMonth").setSelectedKey("1");
					this.getView().byId("slYear").setSelectedKey(String(Number(this.getView().byId("slYear").getSelectedKey()) + 1));
				} else {
					this.getView().byId("slMonth").setSelectedKey(String(Number(this.getView().byId("slMonth").getSelectedKey()) + 1));
				}
				this.onSearch();
			},
			onPressButtonPreMonth: function () {
				const nCurrentMonth = Number(this.getView().byId("slMonth").getSelectedKey());
				if (nCurrentMonth === 1) {
					// Set December and Previous year
					this.getView().byId("slMonth").setSelectedKey("12");
					this.getView().byId("slYear").setSelectedKey(String(Number(this.getView().byId("slYear").getSelectedKey()) - 1));
				} else {
					this.getView().byId("slMonth").setSelectedKey(String(Number(this.getView().byId("slMonth").getSelectedKey()) - 1));
				}

				// Apply Filter
				this.onSearch();
			}
		});
	});