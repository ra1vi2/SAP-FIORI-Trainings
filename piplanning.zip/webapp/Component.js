sap.ui.define([ "sap/ui/core/UIComponent", "sap/ui/model/json/JSONModel"],
		function(UIComponent, JSONModel) {
			"use strict";
			return UIComponent.extend("piBoard.Component", {
				//
				metadata : {
					manifest : "json",
					properties: {},
					 includes : [ "css/piBoard.css" ]
				},
				//
				init : function() {
					//
					// call the init function of the parent.
					UIComponent.prototype.init.apply(this, arguments);

					this.getModel("Local").setSizeLimit(10000);
					
		            var oModel = new JSONModel("./model/CustoData.json", false);
		            this.setModel(oModel, "CustoData");
				}

			});
		});