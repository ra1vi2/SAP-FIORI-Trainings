sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("master.MasterDetail.controller.DetailObjectNotFound", {});
});